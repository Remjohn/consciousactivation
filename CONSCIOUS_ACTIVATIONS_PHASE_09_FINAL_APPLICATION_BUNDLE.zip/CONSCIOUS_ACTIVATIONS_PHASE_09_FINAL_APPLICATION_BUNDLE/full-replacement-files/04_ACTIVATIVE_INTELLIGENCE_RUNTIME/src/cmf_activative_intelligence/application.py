from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from .domain import validate_air_object
from .repositories.air_repository import AirRepository
from .repositories.registry_repository import RegistryRepository
from .services.archetype_service import ArchetypeService
from .services.brand_service import BrandService
from .services.coalition_service import CoalitionService
from .services.context_service import ContextService
from .services.derivative_service import DerivativeService
from .services.hypothesis_service import HypothesisService
from .services.transfer_service import TransferService
from .services.failure_service import FailureService
from .services.learning_service import LearningService
from .services.primitive_service import PrimitiveService
from .services.semantic_authority import SemanticAuthorityService
from .services.phase9_service import Phase9ActivativeService
from .campaign import CampaignActivationService
from .model_evidence import ProgrammedModelEvidenceService


class AirApplication:
    def __init__(self, database_path: str | Path | None = None):
        self.repository = AirRepository(database_path)
        self.registries = RegistryRepository(self.repository)
        self.semantic = SemanticAuthorityService(self.repository)
        self.context = ContextService(self.repository)
        self.primitives = PrimitiveService(self.repository, self.registries)
        self.coalitions = CoalitionService(self.repository, self.registries)
        self.archetypes = ArchetypeService(self.repository, self.registries)
        self.brand = BrandService(self.repository)
        self.learning = LearningService(self.repository)
        self.failures = FailureService(self.repository)
        self.hypotheses = HypothesisService(self.repository)
        self.derivatives = DerivativeService(self.repository)
        self.transfer = TransferService(self.repository)
        self.phase9 = Phase9ActivativeService(self.repository)
        self.campaigns = CampaignActivationService(self.repository)
        self.programmed_model_evidence = ProgrammedModelEvidenceService(self.repository)

    def initialize(self) -> dict[str, Any]:
        return self.repository.initialize()

    def load_registries(self) -> dict[str, Any]:
        return self.registries.import_all()

    def validate(self, object_type: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        return validate_air_object(object_type, payload)

    def store(
        self,
        object_type: str,
        payload: Mapping[str, Any],
        *,
        idempotency_key: str,
        expected_revision: int | None = None,
    ) -> dict[str, Any]:
        if object_type == "matrix_of_edging":
            return self.context.store_matrix(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "activative_context":
            return self.context.store_context(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "identity_dna_candidate_observation":
            return self.context.store_identity_observation(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "psychological_role_tension_contract":
            return self.primitives.store_role_tension(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "primitive_misuse_risk":
            return self.primitives.store_misuse_risk(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "primitive_binding":
            return self.primitives.store_binding(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "primitive_coalition_contract":
            return self.coalitions.store_coalition(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "primitive_evaluation_receipt":
            return self.coalitions.store_evaluation(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "archetype_coalition_program":
            return self.archetypes.store_program(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "brand_context_version":
            return self.brand.store_brand_context(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "voice_dna":
            return self.brand.store_voice_dna(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "visual_dna":
            return self.brand.store_visual_dna(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "distillation_layer_receipt":
            return self.brand.store_distillation_receipt(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "human_resolution_episode":
            return self.learning.capture_human_resolution(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "failure_attribution":
            return self.failures.record_failure(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "repair_program":
            return self.failures.propose_repair(
                payload,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        if object_type == "activation_hypothesis":
            return self.hypotheses.store_hypothesis(payload, idempotency_key=idempotency_key, expected_revision=expected_revision)
        if object_type == "activation_hypothesis_portfolio":
            return self.hypotheses.store_portfolio(payload, idempotency_key=idempotency_key, expected_revision=expected_revision)
        if object_type == "planned_activative_intelligence_pack":
            return self.hypotheses.store_planned_pack(payload, idempotency_key=idempotency_key)
        if object_type == "hypothesis_promotion_receipt":
            return self.hypotheses.promote(payload, idempotency_key=idempotency_key)
        if object_type == "derivative_input_manifest":
            return self.derivatives.store_input_manifest(payload, idempotency_key=idempotency_key)
        if object_type == "derivative_activation_program":
            return self.derivatives.store_program(payload, idempotency_key=idempotency_key)
        if object_type == "jit_authoring_request":
            return self.derivatives.store_jit_request(payload, idempotency_key=idempotency_key)
        if object_type == "script_proposal_artifact":
            return self.derivatives.store_proposal(payload, idempotency_key=idempotency_key)
        if object_type == "final_script_package":
            return self.derivatives.store_script(payload, idempotency_key=idempotency_key, expected_revision=expected_revision)
        if object_type == "animation_scene_package":
            return self.derivatives.store_animation_package(payload, idempotency_key=idempotency_key)
        if object_type == "semantic_production_package":
            return self.derivatives.store_semantic_package(payload, idempotency_key=idempotency_key)
        if object_type == "activation_transfer_contract":
            return self.transfer.store_contract(payload, idempotency_key=idempotency_key)
        if object_type == "source_transformation_lineage":
            return self.transfer.store_lineage(payload, idempotency_key=idempotency_key)
        if object_type == "transfer_checkpoint":
            return self.transfer.store_checkpoint(payload, idempotency_key=idempotency_key)
        if object_type == "activation_transfer_evaluation_receipt":
            return self.transfer.store_evaluation(payload, idempotency_key=idempotency_key)
        if object_type == "transfer_failure":
            return self.transfer.store_failure(payload, idempotency_key=idempotency_key)
        if object_type == "transfer_repair_request":
            return self.transfer.store_repair(payload, idempotency_key=idempotency_key)
        phase9_object_types = {
            "interview_asset_contract", "interview_asset_contract_arm_receipt",
            "live_narrative_policy_proposal", "observed_activative_intelligence_pack",
            "campaign_activation_program", "activation_freshness_profile", "audience_reaction_receipt",
            "campaign_revision_request", "relationship_activation_state", "reelcast_progression_program",
            "visual_activation_handoff", "activation_evaluation_receipt",
            "programmed_model_evidence_candidate",
        }
        if object_type in phase9_object_types:
            normalized = validate_air_object(object_type, payload)
            return self.semantic.store(object_type, normalized, idempotency_key=idempotency_key, expected_revision=expected_revision)
        if object_type == "epistemic_transition_receipt":
            normalized = self.semantic.validate_transition_receipt(payload)
            return self.semantic.store(
                object_type,
                normalized,
                idempotency_key=idempotency_key,
                expected_revision=expected_revision,
            )
        return self.semantic.store(
            object_type,
            payload,
            idempotency_key=idempotency_key,
            expected_revision=expected_revision,
        )

    def status(self) -> dict[str, Any]:
        health = self.repository.health()
        return {
            **health,
            "lifecycle_state": "phase_09_development_release_candidate",
            "development_authorized": True,
            "claim_ceiling": "PHASE_09_DEVELOPMENT_RELEASE_CANDIDATE_EVIDENCE",
            "semantic_runtime_executed": True,
            "semantic_production_compiler_available": True,
            "campaign_activation_runtime": True,
            "programmed_model_evidence_runtime": True,
            "external_model_calls": 0,
            "real_human_evidence_claimed": False,
            "format02_activated": False,
            "vae_stage5_authorized": False,
            "production_authorized": False,
            "certified": False,
        }
