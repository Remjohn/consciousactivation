# Planning Requirements Extraction Baseline

Status: `COMPLETE_PENDING_HUMAN_CONFIRMATION`

Extraction validation authority: `REQUIREMENTS_EXTRACTION_VALIDATION_REPORT.json`

Epic-design gate: `BLOCKED_PENDING_HUMAN_CONFIRMATION`

## Scope

This is Step 1 of `handoff/EPICS_AND_STORIES_HANDOFF.md`. It normalizes every authoritative planning obligation before any epic or story is designed. It contains no production implementation and deliberately leaves `epic_ids` and `story_ids` empty.

## Inventory Counts

| Authority type | Count |
|---|---:|
| Functional requirements | 210 |
| Non-functional requirements | 53 |
| Locked decisions | 33 |
| Accepted ADR obligations | 18 |
| Approved UX clauses | 51 |
| Readiness hard gates | 14 |
| Binding anti-goals | 22 |
| **Total** | **401** |

## FR/NFR Coverage Verdicts

| Verdict | Count |
|---|---:|
| `DEFERRED` | 1 |
| `NEEDS_EMPIRICAL_PROTOTYPE` | 38 |
| `NEW_IMPLEMENTATION` | 216 |
| `NOT_APPLICABLE` | 8 |

The verdicts are copied from `docs/tech-specs/REQUIREMENT_COVERAGE_MATRIX.csv`; this extraction does not reclassify requirements.

## Active Blocker Exposure

- `BD-004` affects 79 inventory rows.
- `BD-007` affects 28 inventory rows.
- `BD-008` affects 49 inventory rows.
- `BD-010` affects 30 inventory rows.
- `BD-014` affects 36 inventory rows.

Resolved blocker IDs remain in `blocking_decisions` for provenance. Only currently unresolved external or empirical blockers appear in `active_blockers`.

## Normalized Schema

Each inventory row includes full normative text, enforcement or acceptance evidence, release scope, the existing coverage verdict where applicable, planning disposition, feature/domain, specs and architecture owners, requirement/ADR/decision/UX links, verification strategy, concrete source evidence, repository coverage basis, blocker provenance, active blockers, and future Epic/Story assignment fields.

## Source Authority

- `governance/REQUIREMENTS_REGISTRY.json`
- `governance/DECISION_REGISTER.json`
- `governance/ARCHITECTURAL_PROHIBITIONS.json`
- `governance/READINESS_HARD_GATES.yaml`
- `docs/tech-specs/REQUIREMENT_COVERAGE_MATRIX.csv`
- `docs/architecture/ARCHITECTURE_TRACEABILITY_MATRIX.csv`
- `docs/architecture/ADR_REGISTER.yaml` and individual ADRs
- `docs/ux/HARNESS_CONTROL_TOWER_UX_CONTRACT.md`
- `docs/ux/CONTROL_TOWER_UX_TRACEABILITY_MATRIX.csv`

## Confirmation Gate

Epic design may begin only after validation passes and human product authority confirms this inventory as the complete planning baseline. Confirmation accepts coverage and extraction, not implementation readiness. The five external or empirical blockers remain open.
