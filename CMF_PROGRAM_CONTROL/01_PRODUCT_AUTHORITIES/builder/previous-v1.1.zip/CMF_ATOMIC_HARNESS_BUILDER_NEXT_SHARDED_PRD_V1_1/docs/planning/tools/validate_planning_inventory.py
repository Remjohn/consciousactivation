from __future__ import annotations

import csv
import json
import re
from collections import Counter
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[3]
PLANNING = ROOT / "docs" / "planning"
GOV = ROOT / "governance"
TECH = ROOT / "docs" / "tech-specs"
ARCH = ROOT / "docs" / "architecture"
UX = ROOT / "docs" / "ux"

INVENTORY = PLANNING / "PLANNING_REQUIREMENTS_INVENTORY.csv"
BASELINE = PLANNING / "REQUIREMENTS_EXTRACTION_BASELINE.md"
REPORT = PLANNING / "REQUIREMENTS_EXTRACTION_VALIDATION_REPORT.json"

ALLOWED_VERDICTS = {
    "IMPLEMENTED_AND_KEEP",
    "IMPLEMENTED_BUT_ALIGN",
    "PARTIALLY_IMPLEMENTED",
    "NEW_IMPLEMENTATION",
    "REPLACE_EXISTING_BEHAVIOR",
    "NEEDS_EMPIRICAL_PROTOTYPE",
    "DEFERRED",
    "NOT_APPLICABLE",
}

EXPECTED_COUNTS = {
    "FUNCTIONAL_REQUIREMENT": 210,
    "NON_FUNCTIONAL_REQUIREMENT": 53,
    "LOCKED_DECISION": 33,
    "ARCHITECTURE_DECISION": 18,
    "UX_CONTRACT_CLAUSE": 51,
    "READINESS_HARD_GATE": 14,
    "BINDING_ANTI_GOAL": 22,
}

REQUIRED_COLUMNS = {
    "inventory_id",
    "authority_type",
    "title",
    "normative_text",
    "acceptance_or_enforcement",
    "release_scope",
    "coverage_verdict",
    "planning_disposition",
    "feature_or_domain",
    "primary_specs",
    "architecture_components",
    "requirement_refs",
    "adr_refs",
    "decision_refs",
    "ux_refs",
    "verification_refs",
    "source_evidence",
    "repository_coverage_basis",
    "blocking_decisions",
    "active_blockers",
    "planning_owner",
    "epic_ids",
    "story_ids",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def refs(value: str | None) -> set[str]:
    if not value:
        return set()
    return {item.strip() for item in value.split(";") if item.strip()}


def source_ids() -> dict[str, set[str]]:
    requirements = json.loads((GOV / "REQUIREMENTS_REGISTRY.json").read_text(encoding="utf-8"))
    decisions = json.loads((GOV / "DECISION_REGISTER.json").read_text(encoding="utf-8"))
    anti_goals = json.loads((GOV / "ARCHITECTURAL_PROHIBITIONS.json").read_text(encoding="utf-8"))
    hard_gates = yaml.safe_load((GOV / "READINESS_HARD_GATES.yaml").read_text(encoding="utf-8"))
    adr_register = yaml.safe_load((ARCH / "ADR_REGISTER.yaml").read_text(encoding="utf-8"))
    ux_contract = (UX / "HARNESS_CONTROL_TOWER_UX_CONTRACT.md").read_text(encoding="utf-8")
    return {
        "FUNCTIONAL_REQUIREMENT": {item["id"] for item in requirements["functional_requirements"]},
        "NON_FUNCTIONAL_REQUIREMENT": {item["id"] for item in requirements["non_functional_requirements"]},
        "LOCKED_DECISION": {item["id"] for item in decisions["decisions"]},
        "ARCHITECTURE_DECISION": {item["id"] for item in adr_register["records"] if item["status"] == "ACCEPTED"},
        "UX_CONTRACT_CLAUSE": set(re.findall(r"\bUXC-\d{3}\b", ux_contract)),
        "READINESS_HARD_GATE": {item["id"] for item in hard_gates["gates"]},
        "BINDING_ANTI_GOAL": {item["id"] for item in anti_goals["anti_goals"]},
    }


def main() -> int:
    errors: list[str] = []

    if not INVENTORY.is_file():
        errors.append("planning requirements inventory is missing")
        rows: list[dict[str, str]] = []
    else:
        rows = read_csv(INVENTORY)

    if rows and set(rows[0]) != REQUIRED_COLUMNS:
        errors.append(f"inventory columns differ: {sorted(set(rows[0]) ^ REQUIRED_COLUMNS)}")

    expected_ids_by_type = source_ids()
    expected_all_ids = set().union(*expected_ids_by_type.values())
    inventory_ids = [row.get("inventory_id", "") for row in rows]
    if len(inventory_ids) != len(set(inventory_ids)):
        errors.append("inventory contains duplicate IDs")
    actual_all_ids = set(inventory_ids)
    if actual_all_ids != expected_all_ids:
        errors.append(
            "inventory IDs differ from authority sources "
            f"missing={sorted(expected_all_ids - actual_all_ids)} "
            f"extra={sorted(actual_all_ids - expected_all_ids)}"
        )

    type_counts = Counter(row.get("authority_type", "") for row in rows)
    if dict(type_counts) != EXPECTED_COUNTS:
        errors.append(f"authority-type counts differ: {dict(sorted(type_counts.items()))}")

    for authority_type, expected_ids in expected_ids_by_type.items():
        actual_ids = {
            row["inventory_id"]
            for row in rows
            if row.get("authority_type") == authority_type
        }
        if actual_ids != expected_ids:
            errors.append(
                f"{authority_type} IDs differ "
                f"missing={sorted(expected_ids - actual_ids)} extra={sorted(actual_ids - expected_ids)}"
            )

    coverage_rows = read_csv(TECH / "REQUIREMENT_COVERAGE_MATRIX.csv")
    verdict_by_id = {row["id"]: row["classification"] for row in coverage_rows}
    blocker_register = yaml.safe_load((TECH / "BLOCKING_DECISIONS.yaml").read_text(encoding="utf-8"))
    known_blockers = {item["id"] for item in blocker_register["decisions"]}
    active_blockers = {
        item["id"]
        for item in blocker_register["decisions"]
        if str(item.get("status", "")).startswith("BLOCKING_")
    }

    valid_spec_refs = {f"TS-{number:02d}" for number in range(16)} | {"IMPLEMENTATION_BASELINE"}

    for row in rows:
        inventory_id = row.get("inventory_id", "<unknown>")
        authority_type = row.get("authority_type", "")
        for field in (
            "title",
            "normative_text",
            "acceptance_or_enforcement",
            "release_scope",
            "planning_disposition",
            "feature_or_domain",
            "primary_specs",
            "verification_refs",
            "source_evidence",
            "repository_coverage_basis",
            "planning_owner",
        ):
            if not row.get(field, "").strip():
                errors.append(f"{inventory_id}: empty {field}")

        verdict = row.get("coverage_verdict", "")
        if authority_type in {"FUNCTIONAL_REQUIREMENT", "NON_FUNCTIONAL_REQUIREMENT"}:
            if verdict not in ALLOWED_VERDICTS:
                errors.append(f"{inventory_id}: invalid coverage verdict {verdict!r}")
            if verdict != verdict_by_id.get(inventory_id):
                errors.append(f"{inventory_id}: coverage verdict differs from Stage 1 matrix")
        elif verdict:
            errors.append(f"{inventory_id}: non-FR/NFR row has a coverage verdict")

        unknown_specs = refs(row.get("primary_specs")) - valid_spec_refs
        if unknown_specs:
            errors.append(f"{inventory_id}: unknown primary specs {sorted(unknown_specs)}")

        blocker_refs = refs(row.get("blocking_decisions"))
        if blocker_refs - known_blockers:
            errors.append(f"{inventory_id}: unknown blockers {sorted(blocker_refs - known_blockers)}")
        expected_active = blocker_refs & active_blockers
        actual_active = refs(row.get("active_blockers"))
        if actual_active != expected_active:
            errors.append(
                f"{inventory_id}: active blockers differ "
                f"expected={sorted(expected_active)} actual={sorted(actual_active)}"
            )

        for source in refs(row.get("source_evidence")):
            source_path = source.split("#", 1)[0]
            if source_path and not (ROOT / source_path).is_file():
                errors.append(f"{inventory_id}: source does not exist: {source_path}")

        if row.get("epic_ids") or row.get("story_ids"):
            errors.append(f"{inventory_id}: Epic/Story assignment exists before inventory confirmation")

    represented_active = {
        blocker
        for row in rows
        for blocker in refs(row.get("active_blockers"))
    }
    if represented_active != active_blockers:
        errors.append(
            "active blocker coverage differs "
            f"missing={sorted(active_blockers - represented_active)} "
            f"extra={sorted(represented_active - active_blockers)}"
        )

    baseline_text = BASELINE.read_text(encoding="utf-8") if BASELINE.is_file() else ""
    if "Status: `COMPLETE_PENDING_HUMAN_CONFIRMATION`" not in baseline_text:
        errors.append("planning baseline status is not COMPLETE_PENDING_HUMAN_CONFIRMATION")
    if "Epic-design gate: `BLOCKED_PENDING_HUMAN_CONFIRMATION`" not in baseline_text:
        errors.append("epic-design gate is not blocked pending confirmation")

    status = "PASS" if not errors else "FAIL"
    report = {
        "status": status,
        "inventory_confirmation_gate": "PENDING_HUMAN_CONFIRMATION",
        "epic_design_gate": "BLOCKED_PENDING_HUMAN_CONFIRMATION",
        "implementation_readiness_gate": "FAIL",
        "inventory_rows": len(rows),
        "authority_type_counts": dict(sorted(type_counts.items())),
        "fr_nfr_verdict_counts": dict(
            sorted(Counter(row["coverage_verdict"] for row in rows if row.get("coverage_verdict")).items())
        ),
        "active_blockers": sorted(active_blockers),
        "epic_assignments": sum(bool(row.get("epic_ids")) for row in rows),
        "story_assignments": sum(bool(row.get("story_ids")) for row in rows),
        "errors": errors,
    }
    REPORT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
