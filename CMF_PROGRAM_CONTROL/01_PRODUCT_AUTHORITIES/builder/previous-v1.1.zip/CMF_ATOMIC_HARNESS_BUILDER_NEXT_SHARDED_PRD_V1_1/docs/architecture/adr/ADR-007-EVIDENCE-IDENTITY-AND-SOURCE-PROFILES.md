# ADR-007: Evidence Identity And Source Profiles

Status: `ACCEPTED`

Owners: Evidence architecture and source authority. Trace: D005, D007, D023; TS-02. External blocker: BD-004.

## Context

Builder decisions depend on exact target evidence. Path-based identity, generic profiles, mutable sources, and unregistered embedded references make provenance and saturation unreliable.

## Decision

Every run selects a versioned target-specific Source Profile and exact target candidate before initialization. Source bytes receive SHA-256 identity, immutable descriptors, authority/license/privacy metadata, stable specimen IDs, and an aggregate Source Lock. All evidence claims link to source spans and knowledge status.

## Alternatives

- Paths as identity: rejected because paths move and bytes change.
- Copy every source into the database: rejected for scale and media operations.
- One universal source checklist: rejected because targets require different evidence roles and readiness.

## Interfaces, Data, And Errors

Ports: source adapter, archive/media inspector, CAS, evidence index. Core records: `SourceProfile`, `SourceDescriptor`, `SourceLock`, `Specimen`, `EvidenceClaim`, `Gap`, `AuthorityConflict`, `SaturationContract`. Errors are typed for unsafe archive, missing role, hash mismatch, unsupported media, authority conflict, and insufficient saturation.

## Authority, Security, And Determinism

Deterministic tools hash, index, and validate. Agents may propose semantic tags but cannot promote authority. Sources are read-only. Archive traversal, symlink escape, decompression bombs, and mutable remote inputs fail closed.

## Consequences

Positive: portable provenance, exact invalidation, repeatable saturation. Cost: profile maintenance, media/CAS capacity, and source-authority review.

## Observability, Performance, Migration

Report files/bytes/specimens, cache hits, duplicates, gaps, conflicts, role coverage, and processing budgets. Changed hashes create a new lock and invalidate dependents. No V2.1 source-profile import applies.

## Verification

Security/property tests cover archives and identity; scale tests cover large descriptor sets; Format 02 cannot proceed without a ratified corpus and profile.

