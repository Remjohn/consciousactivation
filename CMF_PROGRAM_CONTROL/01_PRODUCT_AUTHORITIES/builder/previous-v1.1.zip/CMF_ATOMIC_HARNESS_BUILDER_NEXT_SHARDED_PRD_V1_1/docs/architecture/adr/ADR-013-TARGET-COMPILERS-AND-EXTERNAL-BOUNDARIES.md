# ADR-013: Target Compilers And External Boundaries

Status: `ACCEPTED`

Owners: Cross-product architecture. Trace: D004, D005, D011, D014, D029, D030, D031, D032, D033; TS-11. External blocker: BD-014.

## Context

Builder must compile Atomic Content Harness, Visual Asset Editor, and Delegation Contract targets without flattening them into one profile or importing external production behavior. Content semantic authority must survive compilation.

## Decision

Maintain three versioned `CompilationTargetProfile` records with distinct source profiles, IR projections, Genesis graphs, compilers, artifact sets, evaluation gates, and certification scopes. External target compilers consume read-only versioned interface snapshots and emit schemas/specifications/fixtures/packages only.

Visual Asset Editor and Delegation packages remain `UNCERTIFIED` in Release 1. Their owning repositories control runtime and shared contracts. Cross-target compatibility validates content-owned fields as immutable.

## Alternatives

- Universal target profile: rejected by D004 and D033.
- Vendor external schemas into Builder as editable truth: rejected because ownership and version authority would drift.
- Call external runtimes during compilation: rejected due product boundary and reproducibility.

## Interfaces, Data, And Errors

`TargetCompiler.compile(ir, profile, interface_snapshots) -> TargetPackageManifest`. Errors include missing profile/snapshot, incompatible contract, forbidden semantic mutation, unsupported certification, and external-version mismatch.

## Authority, Security, And Determinism

Compilers have no external runtime credentials/network. Snapshots are read-only and hashed. Human cross-product owners ratify breaking contract versions and certification.

## Consequences

Positive: explicit target differences, preserved ownership, safe structural support. Cost: three compiler/test suites and interface-version coordination.

## Observability, Performance, Migration

Record target/profile/compiler/snapshot identities, compatibility, artifact hashes, and certification. External contract changes invalidate only dependent packages. No V2.1 target migration applies.

## Verification

Boundary tests reject external runtime modules, cross-target semantic rewrites, missing snapshots, false certification, and nondeterministic packages.

