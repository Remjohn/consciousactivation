# ADR-018: Format 02 Asset Demand Boundary

Status: `ACCEPTED`

Owners: Product lead and cross-product architecture. Trace: D004, D014, D030, D032; TS-11, TS-15. Blockers: BD-011, BD-014.

## Context

Format 02 may need character/background/pose/expression assets, but Release 1 must not depend on or implement Visual Asset Editor production behavior. It still needs to prove typed demand and semantic non-mutation boundaries where asset interaction affects the harness.

## Decision

Use a contract-tested stub `AssetDemandPort` backed by approved fixtures. Builder compiles demand contracts and validates responses/provenance but does not generate/edit assets. The port may be omitted only if product authority proves the reference slice has no asset dependency.

## Alternatives

- Build/integrate production Visual Asset Editor: rejected by frozen product boundary and Release 1 scope.
- Ignore asset needs: rejected if it makes the reference path non-representative.
- Free-form file exchange: rejected because provenance and semantic authority are untestable.

## Interfaces, Data, And Errors

`AssetDemand { semantic_intent_ref, asset_kind, constraints, continuity_state, provenance_requirements, content_owned_fields }`; `AssetResponse { demand_ref, asset_refs, provenance, compatibility, warnings }`. Errors include unsupported demand, semantic mutation, missing provenance, incompatible version, and unavailable fixture.

## Authority, Security, And Determinism

Content-owned semantic intent is immutable downstream. Fixtures are hash-locked and non-executable. No editor credentials/network enter Builder.

## Consequences

Positive: realistic boundary proof without cross-product implementation. Cost: interface snapshots, fixtures, and contract tests that may later evolve with the editor owner.

## Observability, Performance, Migration

Record demand/response identities, compatibility, provenance, latency, and boundary violations. Replacing the stub with an external adapter requires contract equivalence and a new/updated ADR.

## Verification

Tests cover valid demand, missing/invalid provenance, semantic mutation, incompatible version, external unavailability, and proof that no editor runtime code exists in Builder.
