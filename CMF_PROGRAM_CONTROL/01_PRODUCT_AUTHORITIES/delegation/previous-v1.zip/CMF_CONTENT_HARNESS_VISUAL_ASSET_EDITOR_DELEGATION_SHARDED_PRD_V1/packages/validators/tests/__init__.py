"""Contract baseline conformance tests."""

