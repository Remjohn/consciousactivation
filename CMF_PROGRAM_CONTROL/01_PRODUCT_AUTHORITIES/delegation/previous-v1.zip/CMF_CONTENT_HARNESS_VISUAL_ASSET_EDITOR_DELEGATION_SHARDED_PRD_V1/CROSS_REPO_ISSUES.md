---
title: Delegation Cross-Repository Issues
product: CMF Content Harness Visual Asset Editor Delegation Protocol
status: open
created: 2026-07-14
---

# Cross-Repository Issues

| ID | Severity | Contradiction or missing evidence | Affected owners | Required resolution | Blocks |
|---|---|---|---|---|---|
| XRI-001 | Critical | The source register names and hashes the Builder PRD, VAE PRD, VAE preservation contract and provisional VAE schemas, but those source files are absent from this checkout. Exact source-to-local contract diffs cannot be reproduced. | Product governance, VAE, Delegation | Supply immutable source artifacts or repository/tag coordinates and verify recorded hashes. | Canonical reconciliation and contract freeze |
| XRI-002 | Critical | Content Harness and VAE implementation repositories, public adapter surfaces and executable tests are absent. Documentation cannot prove current implementation coverage. | Content Harness, VAE | Supply pinned repository revisions and adapter/test entry points. | Cross-product implementation mapping and Format 02 certification |
| XRI-003 | High | `submission-receipt` is produced by `delegation_protocol_or_vae`, while the lifecycle assigns accepted admission to the VAE and rejected validation to the protocol. Shared fields do not have one unconditional owner. | Delegation, VAE | Adopt ADR-DLG-004 and define separate facts/receipts or one protocol receipt over a signed VAE admission fact. | Field-owner gate |
| XRI-004 | Critical | The VAE-produced `asset-result-contract` includes `authorization.downstream_consumption_authorized`, but D006 assigns consumption authorization to the Content Harness or composition runtime. | VAE, Content Harness, Delegation | Remove that field from the result payload and establish it only in `result-acknowledgement`. | D006, FR-042, schema freeze |
| XRI-005 | High | `visual-asset-demand.evaluation_policy` is Content Harness-authored while evaluation implementation and production acceptance are VAE-owned. Its open shape could transfer evaluation strategy. | Content Harness, VAE | Limit the demand to certified profile references, owner-authored gates and bounded repair policy; keep evaluator/workflow strategy VAE-private. | Field authority and VAE sovereignty |
| XRI-006 | Critical | Most nested contract objects are open or untyped. Example-only fields can change without schema/version review, so their ownership and compatibility class are unenforceable. | All producers, Delegation | Close nested schemas or define versioned extension namespaces with explicit owners and compatibility rules. | Contract-family validation |
| XRI-007 | High | Schema documents lack canonical `$id` values and payload-level contract version identity. Message versions live in a separate registry, leaving binding and publication identity underspecified. | Delegation, all consumers | Resolve ADR-DLG-002 and generate a single registry from canonical schema metadata. | Generated types, release pinning and migration |
| XRI-008 | High | Producer/consumer identifiers vary across the contract inventory, message registry and principal registry (`boundary_service`, `delegation_protocol_or_vae`, `owning_product`, and others). | Delegation governance | Normalize identifiers to registered principal types and define permitted conditional authorities. | Deterministic authority validation |
| XRI-009 | High | `visual-asset-event.state` is unconstrained and can expose VAE internal production state, contradicting the stable external projection boundary. | VAE, Delegation | Replace it with typed public event facts and protocol-owned projection mappings; prohibit internal workflow fields. | D004 and VAE encapsulation |
| XRI-010 | Critical | Demand identity propagation is inconsistent. Several contracts carry only a string `demand_ref`, while FR-015 requires exact request ID, version and hash resolution. | Content Harness, VAE, Delegation | Adopt one exact demand-identity reference object across every related message. | Staleness, audit and replay correctness |
| XRI-011 | High | Idempotency and replay are represented by optional envelope fields, a required submission key and an integrity nonce, but no cross-product key/nonce scope or retention agreement exists. | Delegation security, both products | Resolve ADR-DLG-008 with separate duplicate and hostile-replay semantics plus fixtures. | Security and resilience gates |
| XRI-012 | High | `1.0.0-rc.2` now supplies local direct, adapter and owner-evidenced migration golden vectors, but no upstream product manifest/release has run them. | Delegation, both products | Pin product manifests/releases and execute the same equivalence and negative-preservation vectors through real public adapters. | Cross-product compatibility proof |
| XRI-013 | Critical | Format 02 manifests name products and profiles but do not pin accessible source repositories, build artifacts or adapter versions. | Release 1, Content Harness, VAE | Pin exact product releases and executable adapter artifacts. | Format 02 integration certification |
| XRI-014 | High | The PRD requires extension of the existing Harness Control Tower, but its read-model schema, event API and ownership boundary are not available. | Harness Control Tower, Delegation | Supply the existing projection contract and define an additive delegation projection. | GATE-08 |
| XRI-015 | High | Principal authentication is assumed, while identity provider, trust roots, key lifecycle and historical verification infrastructure are unspecified across repositories. | Security architecture, both products | Agree principal IDs, credential lifecycle, signing profile and incident routing. | Integrity proof |
| XRI-016 | Medium | HTTP, queue, stream, local-process and fixture transports are named, but product repositories expose no agreed transport-neutral port or delivery contract. | Delegation, both products | Define ports, delivery metadata, acknowledgement rules and transport conformance fixtures. | FR-007 and integration architecture |
| XRI-017 | Critical | No owner repository is identified for durable protocol state, idempotency/replay records, audit ledger, object references or projection checkpoints. | Platform architecture, Delegation | Assign operational ownership and define storage, transaction, retention, backup and recovery contracts. | Lifecycle, audit and deployment readiness |
| XRI-018 | Medium | `AGENTS.md` is absent locally even though the original audit instruction treated it as the source of workflow verdicts. The attached request supplies the vocabulary but no repository-governed agent policy. | Repository governance | Add the intended `AGENTS.md` or remove the stale dependency from future instructions. | Repeatable audit process only |
| XRI-019 | Critical | `1.0.0-rc.1` used blanket authority ownership. `1.0.0-rc.2` locally replaces it with exact field/item pointer templates and fail-closed tests, but upstream owners have not ratified or consumed the map. | Delegation, Content Harness, VAE | Ratify exact ownership against pinned product schemas and execute denied-path vectors through both adapters. | Contract publication and cross-product authority proof |
| XRI-020 | Critical | `1.0.0-rc.1` diverged from TS-DLG-03. `1.0.0-rc.2` locally implements 19 states, 44 normalized transitions and the complete absent-triple rejection matrix, but product event mappings are unavailable. | Delegation, Content Harness, VAE | Ratify every public fact mapping against pinned product revisions and execute cross-product race schedules. | Lifecycle publication and integration proof |
| XRI-021 | Critical | `1.0.0-rc.1` had non-normative Format 02 scenarios. `1.0.0-rc.2` locally supplies the exact SCN-01 through SCN-10 contract bundles, but real adapters, product executions, Control Tower projections and governed assets are absent. | Delegation, Content Harness, VAE, Control Tower | Execute the canonical bundles through pinned real adapters and produce the signed Format 02 evidence bundle. | Format 02 certification |

No issue in this register authorizes a local override of Content Harness meaning or VAE production fields. Boundary contradictions must be resolved through the owning repository or a governed shared-contract ADR.

## Stage 3 local dispositions

The `1.0.0-rc.1` local contract baseline implements proposed corrections for
XRI-003, XRI-004, XRI-006 through XRI-011 and partially addresses XRI-012.
Those issues remain open for cross-repository ratification; local schemas do
not prove that either product has adopted the corrections.

XRI-001, XRI-002, and XRI-013 through XRI-017 remain direct publication
blockers. The release candidate is therefore unsigned, untagged, and not safe
for product adapter freeze.

The Stage 4 audit added XRI-019 through XRI-021. Their repository-local defects
are corrected in `1.0.0-rc.2`; they remain open until upstream owners ratify
the mappings and execute the canonical vectors through pinned product releases.
