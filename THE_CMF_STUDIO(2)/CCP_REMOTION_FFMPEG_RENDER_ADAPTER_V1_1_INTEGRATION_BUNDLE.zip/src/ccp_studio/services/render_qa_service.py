from __future__ import annotations

from ccp_studio.contracts.remotion_ffmpeg_render_adapter import (
    RenderQAReport,
    FFprobeValidationReceipt,
    FrameSamplingReceipt,
    AudioLevelAnalysisReceipt,
    DurationToleranceReceipt,
)


class RenderQAService:
    def compile_report(
        self,
        *,
        file_ref: str,
        ffprobe_validation: FFprobeValidationReceipt,
        frame_sampling: FrameSamplingReceipt,
        audio_level_analysis: AudioLevelAnalysisReceipt,
        duration_tolerance: DurationToleranceReceipt,
    ) -> RenderQAReport:
        return RenderQAReport(
            file_ref=file_ref,
            ffprobe_validation=ffprobe_validation,
            frame_sampling=frame_sampling,
            audio_level_analysis=audio_level_analysis,
            duration_tolerance=duration_tolerance,
        )
