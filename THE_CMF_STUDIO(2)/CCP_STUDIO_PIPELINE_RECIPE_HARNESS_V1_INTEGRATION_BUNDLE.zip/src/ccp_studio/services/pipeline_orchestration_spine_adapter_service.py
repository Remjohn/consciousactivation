from ccp_studio.contracts.studio_pipeline_recipe_harness import PipelineOrchestrationSpineBinding
class PipelineOrchestrationSpineAdapterService:
    def spine_available(self):
        try:
            import ccp_studio.contracts.orchestration  # noqa: F401
            return True
        except Exception:
            return False
    def compile_binding(self, recipe, orchestration_run_id: str):
        return PipelineOrchestrationSpineBinding(orchestration_run_id=orchestration_run_id, stage_plan_refs={s.step_id:(s.orchestration_stage_ref or s.step_id) for s in recipe.steps}, validation_contract_refs={s.step_id:f'validation:{s.orchestration_stage_ref or s.step_id}' for s in recipe.steps}, spine_available=self.spine_available())
    def compile_stage_plan_requests(self, recipe, orchestration_run_id: str):
        binding=self.compile_binding(recipe, orchestration_run_id)
        return [{'orchestration_run_id': binding.orchestration_run_id, 'pipeline_recipe_id': recipe.recipe_id.value, 'pipeline_step_id': s.step_id, 'stage_ref': binding.stage_plan_refs[s.step_id], 'depends_on': s.depends_on, 'existing_service_refs': s.existing_service_refs} for s in recipe.steps]
