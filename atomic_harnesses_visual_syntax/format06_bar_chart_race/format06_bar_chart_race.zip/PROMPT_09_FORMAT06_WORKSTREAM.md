CMF FORMAT BUILDER MODE — START FORMAT MODULE

I want to build the CMF format module for:

Format 06 — Data Scale Race / Quantified Motion Explainer

Use the CMF Format Builder doctrine:
- Visual syntax first.
- BBOX + WHY.
- Then primitive coalition.
- Then format/dish/runtime eval.
- Bind visual guidance, sonic guidance, design, business, and memetic expression primitives.
- Do not generate final media yet.
- Do not summarize semantic meaning before extracting visual syntax.
- Do not treat topic or data subject as a layout invariant.

Work only on:

format_modules/format06_data_scale_race/

Primary runtime bias:
- Remotion for motion, chart timing, text, and captions.
- SVG/Canvas/D3-like deterministic chart layout for data surfaces.
- FFmpeg for finishing.
- ComfyUI/Flux only for optional icons/portraits/visual anchors, never numeric chart text.

Required outputs:
1. FORMAT_BIBLE.md
2. INGREDIENT_IDENTITIES.md
3. DISH_ATLAS.md
4. SCENE_SYNTAX_ATLAS.md
5. BBOX_WHY_MAPS.md
6. SONIC_GUIDANCE.md
7. DESIGN_BUSINESS_PRIMITIVES.md
8. MEMETIC_EXPRESSION_PRIMITIVES.md
9. RUNTIME_PLAN.md
10. QA_GATES.md
11. REGISTRY_EXPORT.json
12. SPECIMEN_INDEX.md
13. WORKSTREAM_NOTES.md

Start by inspecting the uploaded bar chart race visual specimens. Then produce a work plan and ask me which specimen or scene to Drill-me first.
