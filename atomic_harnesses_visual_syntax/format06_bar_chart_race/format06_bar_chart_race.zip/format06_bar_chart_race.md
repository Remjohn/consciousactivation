# Transcript and Frame Animations for format06_bar_chart_race

## **Transcript and Frame Animations**

* **0:00 - 0:05**
  * **Dialogue:** "how rich is Elon Musk most people have no idea what a trillian dollars really is"
  * **Frame Screenshots:**
    * ![frame_000s.jpg](screenshots/frame_000s.jpg)
    * ![frame_001s.jpg](screenshots/frame_001s.jpg)
    * ![frame_003s.jpg](screenshots/frame_003s.jpg)

* **0:05 - 0:10**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_005s.jpg](screenshots/frame_005s.jpg)
    * ![frame_007s.jpg](screenshots/frame_007s.jpg)
    * ![frame_009s.jpg](screenshots/frame_009s.jpg)

* **0:10 - 0:15**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_011s.jpg](screenshots/frame_011s.jpg)
    * ![frame_013s.jpg](screenshots/frame_013s.jpg)

* **0:15 - 0:20**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_015s.jpg](screenshots/frame_015s.jpg)
    * ![frame_017s.jpg](screenshots/frame_017s.jpg)
    * ![frame_019s.jpg](screenshots/frame_019s.jpg)

* **0:20 - 0:25**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_021s.jpg](screenshots/frame_021s.jpg)
    * ![frame_023s.jpg](screenshots/frame_023s.jpg)

* **0:25 - 0:30**
  * **Dialogue:** "all the way back here at 100 billion we're still scrolling"
  * **Frame Screenshots:**
    * ![frame_025s.jpg](screenshots/frame_025s.jpg)
    * ![frame_027s.jpg](screenshots/frame_027s.jpg)
    * ![frame_029s.jpg](screenshots/frame_029s.jpg)

* **0:30 - 0:35**
  * **Dialogue:** "1790 years pressing a but"
  * **Frame Screenshots:**
    * ![frame_031s.jpg](screenshots/frame_031s.jpg)
    * ![frame_033s.jpg](screenshots/frame_033s.jpg)

* **0:35 - 0:40**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_035s.jpg](screenshots/frame_035s.jpg)
    * ![frame_037s.jpg](screenshots/frame_037s.jpg)
    * ![frame_039s.jpg](screenshots/frame_039s.jpg)

* **0:40 - 0:45**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_041s.jpg](screenshots/frame_041s.jpg)
    * ![frame_043s.jpg](screenshots/frame_043s.jpg)

* **0:45 - 0:50**
  * **Dialogue:** "114155 years"
  * **Frame Screenshots:**
    * ![frame_045s.jpg](screenshots/frame_045s.jpg)
    * ![frame_047s.jpg](screenshots/frame_047s.jpg)
    * ![frame_049s.jpg](screenshots/frame_049s.jpg)

* **0:50 - 0:55**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_051s.jpg](screenshots/frame_051s.jpg)
    * ![frame_053s.jpg](screenshots/frame_053s.jpg)

* **0:55 - 1:00**
  * **Dialogue:** "what is 670 mi tall the most expensive plane you can ever buy"
  * **Frame Screenshots:**
    * ![frame_055s.jpg](screenshots/frame_055s.jpg)
    * ![frame_057s.jpg](screenshots/frame_057s.jpg)
    * ![frame_059s.jpg](screenshots/frame_059s.jpg)

* **1:00 - 1:05**
  * **Dialogue:** "367"
  * **Frame Screenshots:**
    * ![frame_061s.jpg](screenshots/frame_061s.jpg)
    * ![frame_062s.jpg](screenshots/frame_062s.jpg)
    * ![frame_064s.jpg](screenshots/frame_064s.jpg)

* **1:05 - 1:10**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_066s.jpg](screenshots/frame_066s.jpg)
    * ![frame_068s.jpg](screenshots/frame_068s.jpg)

* **1:10 - 1:13**
  * **Dialogue:** [No dialogue detected / Music only]
  * **Frame Screenshots:**
    * ![frame_070s.jpg](screenshots/frame_070s.jpg)
    * ![frame_072s.jpg](screenshots/frame_072s.jpg)

