# Sister - Blood of My Blood (Victorian Poetry)

## Video Metadata
- **Subfolder**: `format08_sister_blood_of_my_blood`
- **Dimensions**: `720x1280`
- **Aspect Ratio**: `0.562`
- **Duration**: `21.83s`
- **FPS**: `30.00`

## Transcription (Spoken Content)
> in English they say sister but in poetry we say she's the Blood of My Blood The Heart Of My Heart the one who knew you before you knew yourself who holds your secrets like this sacred who loves you... not because she has to but because she's simply can't imagine doing anything else

## Visual Elements & screenshots
Screenshots are located in `./screenshots/` directory.
