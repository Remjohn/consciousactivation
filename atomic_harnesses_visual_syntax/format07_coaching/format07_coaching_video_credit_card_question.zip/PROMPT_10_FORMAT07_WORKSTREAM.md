CMF FORMAT BUILDER MODE — START FORMAT MODULE

I want to build the CMF format module for:

Format 07 — Direct Coaching A-Roll / Tactical Response Video

Use the CMF Format Builder doctrine:
- Visual syntax first.
- BBOX + WHY.
- Then primitive coalition.
- Then format/dish/runtime eval.
- Bind visual guidance, sonic guidance, design, business, and memetic expression primitives.
- Do not generate final media yet.
- Do not summarize semantic meaning before extracting visual syntax.
- Do not treat topic or business niche as a layout invariant.

Work only on:

format_modules/format07_direct_coaching_video/

Primary runtime bias:
- Source video / A-roll spine.
- Remotion for captions, question cards, reference inserts, punch-ins, layout, and timing.
- FFmpeg for finishing.
- ComfyUI/Flux only for optional reference visuals, never as the primary video spine.

Required outputs:
1. FORMAT_BIBLE.md
2. INGREDIENT_IDENTITIES.md
3. DISH_ATLAS.md
4. SCENE_SYNTAX_ATLAS.md
5. BBOX_WHY_MAPS.md
6. POSE_GAZE_ACTING.md
7. SONIC_GUIDANCE.md
8. DESIGN_BUSINESS_PRIMITIVES.md
9. MEMETIC_EXPRESSION_PRIMITIVES.md
10. RUNTIME_PLAN.md
11. QA_GATES.md
12. REGISTRY_EXPORT.json
13. SPECIMEN_INDEX.md
14. WORKSTREAM_NOTES.md

Start by inspecting the uploaded coaching video visual specimens. Then produce a work plan and ask me which specimen or moment to Drill-me first.
