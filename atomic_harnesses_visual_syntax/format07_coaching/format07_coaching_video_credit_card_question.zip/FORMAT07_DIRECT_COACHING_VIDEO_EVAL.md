# Format 07 — Direct Coaching A-Roll / Tactical Response Video

## Verdict

Yes, this deserves to become a separate CMF format.

It should not be folded into Format 01. Format 01 is story-video with an emotional narrative arc. Format 07 is direct coaching: a real or synthetic coach answers a question, objection, problem, or scenario with tactical judgment. It is source-video-first, not montage-first.

The uploaded coaching specimens show a talking-head coach against a dark studio background, microphone foreground, punchy question card, subtitles, occasional product/book/reference insert, and expressive hand/face reactions. The format's power is not visual complexity. Its power is authority, speed, directness, and conversational realism.

## Format identity

```json
{
  "format_key": "format07_direct_coaching_video",
  "format_name": "Direct Coaching A-Roll / Tactical Response",
  "frame_profile": "9:16_VERTICAL_VIDEO",
  "runtime_bias": "source_video_remotion_ffmpeg",
  "primary_runtime": "source_video_spine",
  "composition_runtime": "remotion",
  "finishing_runtime": "ffmpeg"
}
```

## Core promise

Turn a real audience question, client objection, or business dilemma into a direct tactical answer with authority and conversational realism.

## Native mental model

- question-to-answer
- objection reframing
- tactical decision
- scenario diagnosis
- mistake correction
- business judgment
- emotional regulation under pressure

## Core visual syntax

```text
talking_head_source_video
+ question card hook
+ subtitle emphasis
+ microphone / desk authority
+ occasional reference insert
+ punch-in / crop changes
+ hand gesture beats
+ direct coaching cadence
```

## Main ingredients

### 1. A-roll coach spine

The source video is the spine. It cannot be replaced by B-roll, AI scene generation, or floating text. The coach's face, hands, gaze, and pauses are the main performance.

### 2. Question card

The question card is the hook and source of tension. It gives the viewer a problem to hold while listening.

### 3. Subtitle/emphasis layer

The subtitle layer is not generic captions. It is an emphasis system: keywords, yellow highlights, red question card, white/yellow contrast, short chunks.

### 4. Reference insert

Optional. A book, ad, chart, product, website, screenshot, or proof object can appear when the coach mentions a concrete anchor.

### 5. Gesture / expression beats

Hands, leaning forward, looking down, eye contact, deadpan, frustration, and calm resolve are part of the visual syntax.

## BBOX syntax seed

```json
{
  "frame_profile": "9:16",
  "components": [
    {
      "id": "coach_face_and_torso",
      "bbox": [0.12, 0.05, 0.88, 0.82],
      "role": "authority_performance_spine",
      "why": "The coach's face, hands, and posture carry trust and judgment.",
      "invariant": true
    },
    {
      "id": "microphone_desk_foreground",
      "bbox": [0.25, 0.48, 0.75, 0.90],
      "role": "studio_authority_anchor",
      "why": "Grounds the advice as a recorded coaching answer rather than floating commentary.",
      "invariant": false
    },
    {
      "id": "question_card",
      "bbox": [0.08, 0.58, 0.76, 0.76],
      "role": "problem_hook",
      "why": "Creates immediate tension and tells the viewer what is being answered.",
      "invariant": true
    },
    {
      "id": "subtitle_emphasis",
      "bbox": [0.14, 0.30, 0.86, 0.62],
      "role": "spoken_logic_highlight",
      "why": "Lets the viewer follow the coaching logic in short chunks.",
      "invariant": true
    },
    {
      "id": "reference_insert",
      "bbox": [0.34, 0.52, 0.66, 0.76],
      "role": "concrete_example_or_proof",
      "why": "Appears only when a concrete reference sharpens the answer.",
      "invariant": false
    }
  ]
}
```

## Invariants

- source video / coach performance is the spine;
- question card or source problem appears early;
- subtitles are chunked and emphasized;
- coach gestures remain visible;
- no random B-roll replacing the answer;
- reference inserts are optional but must be relevant;
- audio clarity is mandatory;
- conversational realism is preserved;
- punch-ins must follow emphasis, not random edits.

## Variants

- solo coach, interview clip, podcast clip, recorded voice + still coach, synthetic avatar only if brand-approved;
- question card style;
- subtitle styling;
- background/studio;
- reference insert type;
- cut rhythm;
- emotional tone: calm, blunt, funny, skeptical, urgent.

## Failure modes

- captions cover the face or hands;
- question card stays too long and blocks performance;
- generic stock B-roll interrupts the answer;
- overly polished corporate subtitles remove conversational realism;
- jump cuts feel random;
- coach becomes too small;
- audio is unclear;
- reference insert is decorative;
- no clear question/problem.

## Required primitives

### Visual

- frame_profile
- bbox
- attention_path
- safe_zone
- text_placement
- gaze_vector
- pose_line_of_action
- silhouette_clarity
- visual_rhythm

### Sonic

- conversational_realism through audio preservation
- breath_pause
- tempo
- text_reveal_sync
- impact_cue for key corrections
- silence windows for serious moments

### Design

- typography
- legibility
- hierarchy
- contrast
- accessibility
- consistency

### Business

- brand_context_fit
- trust_signal
- audience_state_fit
- offer_path
- reuse_potential
- production_cost
- shareability

### Memetic

- extractable_pose
- reaction_face
- deadpan_mundanity
- conversational_realism
- not_centroid_pose
- screencap_readability

## QA gates

- Spoken audio legible.
- Captions aligned to speech.
- Question card does not obscure coach.
- Face/hands visible during key beats.
- Reference inserts are source-backed.
- No filler B-roll.
- Punch-ins match emphasis.
- Render QA validates audio, captions, frame samples, and duration.

## Needed dishes

1. Question card answer.
2. Stubborn client / business dilemma diagnosis.
3. Mistake correction.
4. Two separate problems reframing.
5. "Don't nuke the business" emotional regulation answer.
6. Book/framework reference answer.
7. Customer acquisition tactical answer.
8. Sales objection response.
9. Founder therapy / reality check.
10. Calm blunt advice clip.
