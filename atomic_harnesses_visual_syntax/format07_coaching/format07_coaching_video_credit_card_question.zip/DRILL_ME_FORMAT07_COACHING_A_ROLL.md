# DRILL_ME_FORMAT07_COACHING_A_ROLL.md

Use this when interrogating a Format 07 direct coaching specimen.

Do not summarize the advice first.
Do not treat the topic as the dish.
Start with A-roll visual syntax.

Required interrogation:

1. What is the coach face/torso BBOX?
2. Are hands visible during key beats?
3. Where is the question card?
4. Where are subtitles/emphasis captions?
5. Does any overlay cover face/hands?
6. Is there a reference insert? Why?
7. What pose/gaze/emotional realism primitives appear?
8. What audio/conversational realism primitives appear?
9. What punch-ins/crops happen and why?
10. What runtime owns each layer?
11. What QA gates prove this is not filler A-roll?

Required output:

```json
{
  "format": "format07_direct_coaching_video",
  "approval_status": "blocked | revise | approve",
  "bbox_why_components": [],
  "pose_gaze_plan": {},
  "sonic_plan": {},
  "visual_primitives": [],
  "sonic_primitives": [],
  "design_primitives": [],
  "business_primitives": [],
  "memetic_expression_primitives": [],
  "runtime_plan": {},
  "qa_gates": [],
  "blockers": []
}
```

Block if captions obscure the coach, the question is missing, audio is unclear, or B-roll replaces the answer spine.
