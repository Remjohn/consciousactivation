# Format 02 Minimal Coach Theatre

## Active element law
Maximum 3 active elements:
1. Guide character/body/gesture.
2. Text field/paper card/written thought.
3. Meaning object/proof/diagram/icon.

## Hard laws
- 9:16 vertical.
- No lip sync.
- Big negative space.
- Deterministic text.
- Prop carrying requires attachment points.
- Avoid default centered front-facing gaze.
- Remotion-first runtime.
