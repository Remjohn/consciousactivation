"""Deterministic AIR semantic services."""
