# Apply Skill Architecture Refactor + SuperVisual Builder Patch V1

## Preconditions

Apply this patch after Contract Convergence + Registry Consolidation is committed in the real repo.

## What this patch adds

```text
docs/architecture/skills/SKILL_ARCHITECTURE_REFACTOR_V1.md
registries/canonical/skills/shared/*.skill.yaml
registries/canonical/skills/supervisual/*.skill.yaml
registries/canonical/skills/skill_architecture_refactor.v1.json
registries/canonical/skills/supervisual/supervisual_corrected_execution_graph.v1.json
src/ccp_studio/contracts/shared_skill_packs.py
src/ccp_studio/contracts/supervisual_builder.py
src/ccp_studio/services/supervisual_builder_service.py
tests/cmf_studio/test_skill_architecture_and_supervisual_builder.py
operator-web/src/screens/SuperVisualStudio.jsx
operator-web/src/styles/supervisual.css
operator-web/src/fixtures/supervisualStudio.fixture.js
```

## Verification

```bash
PYTHONPATH=src python -m compileall -q src
PYTHONPATH=src python -m pytest -q tests/cmf_studio
cd operator-web
npm run build
```

## Commit

```bash
git add .
git commit -m "feat(supervisual): add shared skill packs and premium SuperVisual Studio"
```
