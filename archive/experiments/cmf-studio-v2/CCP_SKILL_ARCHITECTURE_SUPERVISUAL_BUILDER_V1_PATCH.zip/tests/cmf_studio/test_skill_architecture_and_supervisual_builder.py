from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

import pytest

from ccp_studio.contracts.frame_profiles import FrameProfileCode
from ccp_studio.contracts.supervisual_builder import CreateSuperVisualRequest
from ccp_studio.services.supervisual_builder_service import SuperVisualBuilderService


ROOT = Path(__file__).resolve().parents[2]


def test_skill_architecture_registry_separates_shared_and_supervisual_skills():
    path = ROOT / "registries" / "canonical" / "skills" / "skill_architecture_refactor.v1.json"
    registry = json.loads(path.read_text(encoding="utf-8"))
    shared = [skill for skill in registry["skills"] if skill["scope"] == "shared"]
    supervisual = [skill for skill in registry["skills"] if skill["scope"] == "supervisual"]
    assert len(shared) >= 12
    assert len(supervisual) == 9
    assert "shared.visual_schema.compile" in {skill["id"] for skill in shared}
    assert "supervisual.copy_packet.compile" in {skill["id"] for skill in supervisual}


def test_supervisual_execution_graph_uses_shared_skills_before_engine_specific_skills():
    path = ROOT / "registries" / "canonical" / "skills" / "supervisual" / "supervisual_corrected_execution_graph.v1.json"
    graph = json.loads(path.read_text(encoding="utf-8"))
    runtime_path = graph["supervisual_runtime_path"]
    assert runtime_path[0] == "shared.context.hydrate"
    assert "supervisual.project.create" in runtime_path
    assert runtime_path.index("shared.visual_schema.compile") < runtime_path.index("supervisual.project.create")
    assert runtime_path.index("shared.composition.lock") < runtime_path.index("shared.provider_jobs.plan")


def test_supervisual_service_builds_evaluated_project_with_fake_providers():
    request = CreateSuperVisualRequest(
        brand_id=uuid4(),
        brand_context_version_id=uuid4(),
        operator_id=uuid4(),
        source_reference_ids=[uuid4()],
        requested_frame_profile=FrameProfileCode.feed_poster,
    )
    result = SuperVisualBuilderService().build_with_fake_providers(request)
    variant = result.project.variants[0]
    assert result.fake_provider_mode is True
    assert result.project.state == "evaluated"
    assert variant.composition_decision is not None
    assert variant.provider_jobs
    assert variant.render_contract is not None
    assert variant.render_contract.deterministic is True
    assert variant.evaluation_receipt is not None
    assert variant.evaluation_receipt.decision == "pass"


def test_supervisual_service_rejects_16_9_delivery_frame_profile():
    with pytest.raises(ValueError, match="16:9"):
        CreateSuperVisualRequest(
            brand_id=uuid4(),
            brand_context_version_id=uuid4(),
            operator_id=uuid4(),
            source_reference_ids=[uuid4()],
            requested_frame_profile=FrameProfileCode.source_interview_16_9,
        )


def test_supervisual_service_accepts_1_1_soft_rounded_delivery_frame_profile():
    request = CreateSuperVisualRequest(
        brand_id=uuid4(),
        brand_context_version_id=uuid4(),
        operator_id=uuid4(),
        source_reference_ids=[uuid4()],
        requested_frame_profile=FrameProfileCode.square_soft_rounded_editorial,
    )
    result = SuperVisualBuilderService().build_with_fake_providers(request)
    assert result.project.variants[0].composition_hypotheses[0].frame_profile == FrameProfileCode.square_soft_rounded_editorial


def test_provider_jobs_are_blocked_until_composition_decision_receipt_exists():
    request = CreateSuperVisualRequest(
        brand_id=uuid4(),
        brand_context_version_id=uuid4(),
        operator_id=uuid4(),
        source_reference_ids=[uuid4()],
    )
    service = SuperVisualBuilderService()
    context = service.hydrate_context(request)
    brief = service.compile_brief(request, context)
    layer_plan = service.compile_layer_plan(
        decision=service.lock_composition(service.generate_composition_hypotheses(request)[0], request.operator_id),
        source_reference_id=request.source_reference_ids[0],
    )
    with pytest.raises(ValueError, match="CompositionDecisionReceipt"):
        service.plan_provider_jobs(
            layer_plan=layer_plan,
            decision=None,
            frame_profile=request.requested_frame_profile,
            style_route_code=request.preferred_style_route_code,
        )


def test_provider_jobs_include_required_preflight_fields():
    request = CreateSuperVisualRequest(
        brand_id=uuid4(),
        brand_context_version_id=uuid4(),
        operator_id=uuid4(),
        source_reference_ids=[uuid4()],
    )
    result = SuperVisualBuilderService().build_with_fake_providers(request)
    job = result.project.variants[0].provider_jobs[0]
    assert job.source_reference_id == request.source_reference_ids[0]
    assert job.primitive_binding_ref
    assert job.style_route_code
    assert job.frame_profile == request.requested_frame_profile
    assert job.composition_role
    assert job.idempotency_key
