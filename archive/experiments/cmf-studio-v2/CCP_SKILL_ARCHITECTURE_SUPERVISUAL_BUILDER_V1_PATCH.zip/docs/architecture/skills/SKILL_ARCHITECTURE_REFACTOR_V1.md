# Skill Architecture Refactor V1

## Purpose

This refactor corrects the earlier SuperVisual skill bundle by separating **shared production skills** from **engine-specific skills**.

The previous SuperVisual V1 skill list was useful as a pipeline draft, but it mixed shared upstream capabilities into the SuperVisual namespace. That made SuperVisual look heavier than Carousel or Video. The canonical architecture is now:

```text
Shared Skill Packs
        ↓
Engine-Specific Skill Packs
        ↓
Component Runtime Services
        ↓
Operator Workbenches
```

## Definitions

### Component

A component is a bounded product/runtime system. It owns contracts, services, repositories, state machines, API endpoints, UI surfaces, tests, receipts, and operator workflows.

Examples:

```text
SuperVisual Engine
Carousel Engine
Video Editing Engine
Asset Intelligence System
Visual Preproduction System
Provider Orchestrator
Review Engine
```

### Skill

A skill is an executable capability used by an agent or sub-agent. It owns inputs, outputs, hard gates, required contracts, required registries, optional DSPy program binding, and receipt requirements.

Examples:

```text
shared.visual_schema.compile
shared.provider_jobs.plan
supervisual.copy_packet.compile
carousel.sequence_strategy.compile
video.timeline_compose
```

### Agent

An agent or sub-agent is the orchestrator that calls skills. It should not bypass the typed skill runtime.

### Contract

A contract is the typed Pydantic object passed between skills and components.

### Registry

A registry is the canonical menu of allowed primitives, style routes, frame profiles, composition templates, provider capabilities, eval rubrics, and skill bindings.

## Runtime Doctrine

```text
Pydantic = contract authority
DSPy = bounded reasoning/compiler layer
Deterministic Python = gates, validation, state transitions, hashes, receipts
Provider Adapters = external execution only after preflight
```

No provider job can run from freeform text. Operator feedback must compile into typed revision commands.

## Shared Skill Packs

The shared skill namespace is reusable across SuperVisual, Carousel, Video, Paper-Cut Artifact, B-roll generation, and future engines.

```text
shared.context
shared.primitive
shared.visual_schema
shared.visual_ingredients
shared.asset
shared.style_route
shared.frame_profile
shared.composition
shared.provider_jobs
shared.asset_materialize
shared.render
shared.eval
shared.revision
shared.receipts
```

## Engine Skill Packs

Engine-specific skills should only represent operations unique to that engine.

```text
engines.supervisual
engines.carousel
engines.video
engines.character
```

## Corrected SuperVisual Scope

SuperVisual is the single-image/still-visual production engine. It calls shared skills for context, primitives, visual schema, asset retrieval, style routing, frame profiles, provider jobs, render, eval, and revision.

SuperVisual-specific skills are only:

```text
supervisual.project.create
supervisual.brief.compile
supervisual.reference_board.prepare
supervisual.copy_packet.compile
supervisual.composition_hypotheses.generate
supervisual.layer_plan.compile
supervisual.variant.render
supervisual.variant.compare
supervisual.export.prepare
```

## Dependency Graph

```text
shared.context.hydrate
→ shared.primitive.coalition.bind
→ shared.visual_schema.compile
→ shared.visual_ingredients.requirements.compile
→ shared.asset.retrieve
→ supervisual.project.create
→ supervisual.brief.compile
→ supervisual.reference_board.prepare
→ shared.style_route.select
→ shared.frame_profile.select
→ supervisual.copy_packet.compile
→ supervisual.composition_hypotheses.generate
→ shared.composition.lock
→ supervisual.layer_plan.compile
→ shared.provider_jobs.plan
→ shared.asset_materialize.execute
→ shared.render_contract.compile
→ supervisual.variant.render
→ shared.eval.run
→ supervisual.variant.compare
→ supervisual.export.prepare
→ shared.revision.apply
```

## Hard Laws

1. 16:9 is source-only for short-form; it is never a delivery frame for SuperVisual, Carousel, or short-form video outputs.
2. A provider job requires source reference, primitive binding, style route, frame profile, composition role, and eval requirements.
3. No provider image generation/editing/segmentation/decomposition runs before CompositionDecisionReceipt.
4. Final render is deterministic and cannot call image providers.
5. CAC, Paper-Cut Artifact, and Documentary Proof require real-life/source references.
6. GMG Expert 03 requires a photo cutout object.
7. GMG Expert 04 requires documentary/proof/archive/artifact input.
8. GMG experts are not averaged unless a composition contract explicitly allows multi-style assembly.
9. Operator revisions are typed patch commands, not hidden mutations.
10. All state-changing operations produce receipts.
