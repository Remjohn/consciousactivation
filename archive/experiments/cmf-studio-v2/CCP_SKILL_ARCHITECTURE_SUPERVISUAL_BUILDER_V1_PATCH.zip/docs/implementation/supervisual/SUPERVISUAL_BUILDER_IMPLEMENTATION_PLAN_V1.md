# SuperVisual Builder Implementation Plan V1

## Objective

Implement the first production component on top of the converged ontology: **SuperVisual Engine**.

SuperVisual is intentionally the first runtime proof because it exercises the full creative doctrine in the smallest unit:

```text
Context → Primitive Coalition → Visual Schema → Ingredients → Style Route → Frame Profile → Composition Lock → Provider Jobs → Deterministic Render → Eval → Operator Approval
```

## Implementation Order

1. Add shared skill packs.
2. Add corrected SuperVisual-specific skills.
3. Add SuperVisualBuilderService with fake providers.
4. Add tests for skills, service, and hard gates.
5. Add SuperVisual Studio premium operator UI.
6. Later replace fake providers with real provider adapters.

## Service Boundary

```text
src/ccp_studio/services/supervisual_builder_service.py
```

The service is a runtime orchestrator. It should call skills and validate contracts, not invent doctrine.

## Fake Provider Doctrine

Fake providers are allowed for implementation proof, but they must still produce:

```text
provider_job_receipt_id
idempotency_key
asset_hash
source_reference_id
style_route_code
frame_profile_code
composition_role
```

Fake provider outputs are not automatic final approvals.

## UI Boundary

```text
operator-web/src/screens/SuperVisualStudio.jsx
operator-web/src/styles/supervisual.css
```

The initial UI is a premium decision cockpit, not a Photoshop clone.

Core panels:

```text
Context / Lineage
Reference Board
Composition Options
Canvas Preview
Inspector + Agent Commands
Jobs / Evals / Receipts
```
