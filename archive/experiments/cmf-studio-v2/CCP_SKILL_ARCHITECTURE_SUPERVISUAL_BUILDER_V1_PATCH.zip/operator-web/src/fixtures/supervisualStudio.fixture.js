export const superVisualProject = {
  id: "SPV-CLNTAH-001",
  title: "The Proof Was Already in the Object",
  state: "Composition Locked",
  brand: "Claude Ntahuga",
  brandContextVersion: "bcv-claude-2026-06-v3",
  primitiveCoalition: {
    signature: "trust-transfer / memory-object / visual-sonic-guidance",
    coverage: 91,
    edgeRisk: 12,
  },
  frameProfiles: ["4:5_FEED_POSTER", "1:1_SOFT_ROUNDED_EDITORIAL", "1:1_PROOF_CARD", "9:16_FULL_VERTICAL"],
  selectedFrameProfile: "1:1_SOFT_ROUNDED_EDITORIAL",
  styleRoute: "GMG Expert 04 — Paper Architect",
  sourceTruth: "A single physical artifact can carry the whole transformation when it remains tied to the speaker's actual story.",
  audienceQuestion: "What object in my own life already proves the change?",
};

export const referenceBoard = [
  { id: "ref-01", type: "Proof Object", title: "Annotated interview note", score: 94, state: "Approved", role: "foreground proof" },
  { id: "ref-02", type: "Memory Object", title: "Chipped ceramic mug", score: 89, state: "Needs crop", role: "micro-semiotic anchor" },
  { id: "ref-03", type: "Paper Texture", title: "Warm off-white fiber", score: 87, state: "Approved", role: "background tactility" },
  { id: "ref-04", type: "Composition Ref", title: "Single artifact assertion", score: 92, state: "Approved", role: "layout source" },
];

export const compositionOptions = [
  { id: "cmp-a", title: "Single Artifact Assertion", fit: 92, risk: "Low", path: ["Artifact", "Headline", "Proof mark"] },
  { id: "cmp-b", title: "Soft Card Editorial Proof", fit: 89, risk: "Medium", path: ["Rounded card", "Object", "Caption"] },
  { id: "cmp-c", title: "Evidence Stack Minimal", fit: 84, risk: "Medium", path: ["Tape", "Document", "Annotation"] },
];

export const productionSteps = [
  { id: "context", label: "Context", state: "passed" },
  { id: "primitive", label: "Primitive", state: "passed" },
  { id: "schema", label: "Visual Schema", state: "passed" },
  { id: "assets", label: "References", state: "passed" },
  { id: "style", label: "Style Route", state: "passed" },
  { id: "frame", label: "Frame", state: "passed" },
  { id: "compose", label: "Composition", state: "locked" },
  { id: "provider", label: "Provider Jobs", state: "queued" },
  { id: "render", label: "Render", state: "waiting" },
  { id: "eval", label: "Eval", state: "waiting" },
];

export const providerJobs = [
  { id: "job-01", provider: "fake_image_provider", target: "hero proof object", status: "completed", hash: "a31d9f8e" },
  { id: "job-02", provider: "fake_layer_provider", target: "paper texture matte", status: "queued", hash: "pending" },
];

export const evalGates = [
  { gate: "Source Fidelity", score: 91, state: "pass" },
  { gate: "Primitive Fit", score: 90, state: "pass" },
  { gate: "Composition Fidelity", score: 93, state: "pass" },
  { gate: "Mobile Readability", score: 88, state: "pass" },
  { gate: "Doctrine Boundary", score: 100, state: "pass" },
];
