import { useMemo, useState } from "react";
import {
  compositionOptions,
  evalGates,
  productionSteps,
  providerJobs,
  referenceBoard,
  superVisualProject,
} from "../fixtures/supervisualStudio.fixture.js";

function cx(...names) {
  return names.filter(Boolean).join(" ");
}

function StepRail() {
  return (
    <div className="spv-step-rail">
      {productionSteps.map((step, index) => (
        <div className={cx("spv-step", step.state)} key={step.id}>
          <span>{String(index + 1).padStart(2, "0")}</span>
          <strong>{step.label}</strong>
          <em>{step.state}</em>
        </div>
      ))}
    </div>
  );
}

function ReferenceBoard() {
  return (
    <section className="spv-panel">
      <div className="spv-panel-head">
        <span>Ingredient Intelligence</span>
        <h3>Reference Board</h3>
      </div>
      <div className="spv-reference-grid">
        {referenceBoard.map((item) => (
          <button className="spv-ref-card" key={item.id} type="button">
            <span>{item.type}</span>
            <strong>{item.title}</strong>
            <small>{item.role}</small>
            <em>{item.score}</em>
          </button>
        ))}
      </div>
    </section>
  );
}

function CompositionOptions({ selected, onSelect }) {
  return (
    <section className="spv-panel">
      <div className="spv-panel-head">
        <span>Composition</span>
        <h3>Hypotheses</h3>
      </div>
      <div className="spv-composition-list">
        {compositionOptions.map((option) => (
          <button
            className={cx("spv-composition-option", selected === option.id && "selected")}
            key={option.id}
            type="button"
            onClick={() => onSelect(option.id)}
          >
            <div>
              <strong>{option.title}</strong>
              <span>{option.path.join(" → ")}</span>
            </div>
            <em>{option.fit}%</em>
          </button>
        ))}
      </div>
    </section>
  );
}

function CanvasPreview({ selected }) {
  const current = compositionOptions.find((item) => item.id === selected) || compositionOptions[0];
  return (
    <section className="spv-canvas-stage" aria-label="SuperVisual canvas preview">
      <div className="spv-canvas-toolbar">
        <span>{superVisualProject.selectedFrameProfile}</span>
        <strong>{current.title}</strong>
        <button type="button">Lock Variant</button>
      </div>
      <div className="spv-canvas-shell">
        <div className="spv-soft-card">
          <div className="spv-paper-object">
            <span className="spv-tape left" />
            <span className="spv-tape right" />
            <div className="spv-object-lines">
              <i />
              <i />
              <i />
            </div>
            <strong>PROOF</strong>
          </div>
          <div className="spv-headline-block">
            <span>SOURCE-FIRST</span>
            <h2>The proof was already in the object.</h2>
            <p>A single artifact can carry the whole transformation.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Inspector() {
  const [command, setCommand] = useState("Make the card more editorial, keep the proof object recognizable, and preserve the source quote.");
  return (
    <aside className="spv-inspector">
      <section className="spv-panel glass">
        <div className="spv-panel-head">
          <span>Lineage</span>
          <h3>Contract Stack</h3>
        </div>
        <dl className="spv-lineage">
          <div><dt>Brand Context</dt><dd>{superVisualProject.brandContextVersion}</dd></div>
          <div><dt>Primitive</dt><dd>{superVisualProject.primitiveCoalition.signature}</dd></div>
          <div><dt>Style Route</dt><dd>{superVisualProject.styleRoute}</dd></div>
          <div><dt>Frame</dt><dd>{superVisualProject.selectedFrameProfile}</dd></div>
        </dl>
      </section>
      <section className="spv-panel glass">
        <div className="spv-panel-head">
          <span>Agent Command</span>
          <h3>Typed Revision</h3>
        </div>
        <textarea value={command} onChange={(event) => setCommand(event.target.value)} />
        <div className="spv-command-actions">
          <button type="button">Compile Patch</button>
          <button type="button" className="ghost">Run Eval</button>
        </div>
      </section>
      <section className="spv-panel glass">
        <div className="spv-panel-head">
          <span>Provider</span>
          <h3>Fake Jobs</h3>
        </div>
        <div className="spv-job-list">
          {providerJobs.map((job) => (
            <div className="spv-job" key={job.id}>
              <strong>{job.target}</strong>
              <span>{job.provider}</span>
              <em>{job.status}</em>
            </div>
          ))}
        </div>
      </section>
    </aside>
  );
}

function EvalStrip() {
  return (
    <section className="spv-eval-strip">
      {evalGates.map((gate) => (
        <div className="spv-eval-card" key={gate.gate}>
          <span>{gate.gate}</span>
          <strong>{gate.score}</strong>
          <em>{gate.state}</em>
        </div>
      ))}
    </section>
  );
}

export function SuperVisualStudio({ activeGuest }) {
  const [selectedComposition, setSelectedComposition] = useState("cmp-a");
  const projectTitle = useMemo(() => `${superVisualProject.title} · ${activeGuest?.workspace || "CMF"}`, [activeGuest]);

  return (
    <main className="screen spv-studio">
      <section className="spv-hero">
        <div>
          <span className="eyebrow amber">SuperVisual Studio</span>
          <h2>{projectTitle}</h2>
          <p>{superVisualProject.sourceTruth}</p>
        </div>
        <div className="spv-hero-actions">
          <button type="button" className="primary-button">Create Variant</button>
          <button type="button" className="ghost-button">Open Receipts</button>
          <button type="button" className="ghost-button">Export Preview</button>
        </div>
      </section>

      <section className="spv-grid">
        <aside className="spv-left">
          <StepRail />
          <ReferenceBoard />
          <CompositionOptions selected={selectedComposition} onSelect={setSelectedComposition} />
        </aside>
        <div className="spv-center">
          <CanvasPreview selected={selectedComposition} />
          <EvalStrip />
        </div>
        <Inspector />
      </section>
    </main>
  );
}
