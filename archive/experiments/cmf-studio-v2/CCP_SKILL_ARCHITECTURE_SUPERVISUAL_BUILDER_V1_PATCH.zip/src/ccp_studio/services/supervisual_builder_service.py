"""SuperVisual Builder service with fake providers.

The service proves the corrected architecture:
shared skills feed engine-specific SuperVisual skills, provider jobs are blocked
until composition lock, and final render is deterministic.
"""

from __future__ import annotations

import json
from uuid import UUID

from ccp_studio.contracts.frame_profiles import FrameProfileCode
from ccp_studio.contracts.supervisual_builder import (
    CompositionDecisionReceipt,
    CreateSuperVisualRequest,
    MaterializedAsset,
    ProviderJobReceipt,
    ProviderJobSpec,
    SuperVisualBrief,
    SuperVisualBuildResult,
    SuperVisualCompositionHypothesis,
    SuperVisualContextPacket,
    SuperVisualCopyPacket,
    SuperVisualEvaluationReceipt,
    SuperVisualLayerPlan,
    SuperVisualLayerSpec,
    SuperVisualProject,
    SuperVisualReferenceBoard,
    SuperVisualRenderContract,
    SuperVisualState,
    SuperVisualVariant,
    stable_hash,
)


class SuperVisualBuilderService:
    """Orchestrates a complete SuperVisual build using fake providers."""

    def hydrate_context(self, request: CreateSuperVisualRequest) -> SuperVisualContextPacket:
        return SuperVisualContextPacket(
            brand_id=request.brand_id,
            brand_context_version_id=request.brand_context_version_id,
            operator_id=request.operator_id,
            source_reference_ids=request.source_reference_ids,
            source_expression_refs=request.source_expression_refs,
            content_archetype=request.content_archetype,
            target_output_kind=request.target_output_kind,
            requested_frame_profile=request.requested_frame_profile,
        )

    def compile_brief(self, request: CreateSuperVisualRequest, context: SuperVisualContextPacket) -> SuperVisualBrief:
        return SuperVisualBrief(
            context_packet_id=context.context_packet_id,
            primitive_coalition_contract_ref="primitive_coalition.fake.supervisual.v1",
            visual_schema_ref="visual_schema.fake.supervisual.v1",
            one_sentence_job="Make one source-grounded idea instantly own the feed.",
            source_truth=request.source_truth,
            audience_question=request.audience_question,
            expected_viewer_state=request.expected_viewer_state,
            forbidden_generic_patterns=["generic advice", "stock metaphor", "AI gloss", "unearned drama"],
        )

    def prepare_reference_board(self, brief: SuperVisualBrief, context: SuperVisualContextPacket) -> SuperVisualReferenceBoard:
        return SuperVisualReferenceBoard(
            brief_id=brief.brief_id,
            required_ingredient_refs=["proof_object", "memory_object_or_micro_semiotic_anchor"],
            selected_source_reference_ids=context.source_reference_ids,
            missing_required_ingredients=[],
            coverage_score=0.91,
        )

    def compile_copy_packet(self, request: CreateSuperVisualRequest) -> SuperVisualCopyPacket:
        return SuperVisualCopyPacket(
            headline="The proof was already in the object.",
            support_line="A single artifact can carry the whole transformation when it stays source-grounded.",
            microcopy=["source-first", "composition-locked", "primitive-fit"],
            caption_seed="A visual system should recognize the world before it tries to stylize it.",
            source_fidelity_note=f"Copy is constrained by source truth: {request.source_truth}",
        )

    def generate_composition_hypotheses(self, request: CreateSuperVisualRequest) -> list[SuperVisualCompositionHypothesis]:
        frame = request.requested_frame_profile
        if frame.value.startswith("16:9"):
            raise ValueError("16:9 is source-only and cannot be a SuperVisual delivery frame profile")
        return [
            SuperVisualCompositionHypothesis(
                composition_template_code="supervisual.single_artifact_assertion.v1",
                frame_profile=frame,
                style_route_code=request.preferred_style_route_code,
                attention_path=["artifact", "headline", "support_line", "microcopy"],
                primitive_fit_score=0.92,
                risks=["avoid over-stylizing proof object"],
            ),
            SuperVisualCompositionHypothesis(
                composition_template_code="supervisual.soft_card_editorial_proof.v1",
                frame_profile=FrameProfileCode.square_soft_rounded_editorial,
                style_route_code=request.preferred_style_route_code,
                attention_path=["soft_card", "artifact", "headline"],
                primitive_fit_score=0.89,
                risks=["ensure mobile readability"],
            ),
        ]

    def lock_composition(self, hypothesis: SuperVisualCompositionHypothesis, operator_id: UUID) -> CompositionDecisionReceipt:
        return CompositionDecisionReceipt(
            selected_hypothesis_id=hypothesis.hypothesis_id,
            locked_by=operator_id,
            decision_reason="Best primitive fit with source-grounded artifact clarity.",
            accepted_risks=hypothesis.risks,
        )

    def compile_layer_plan(self, decision: CompositionDecisionReceipt, source_reference_id: UUID) -> SuperVisualLayerPlan:
        return SuperVisualLayerPlan(
            composition_decision_receipt_id=decision.composition_decision_receipt_id,
            layers=[
                SuperVisualLayerSpec(name="soft paper background", layer_type="background", composition_role="background_plate"),
                SuperVisualLayerSpec(name="rounded editorial card", layer_type="card", composition_role="frame_card"),
                SuperVisualLayerSpec(name="hero proof object", layer_type="hero_asset", composition_role="proof_insert", deterministic=False, requires_provider_materialization=True, source_reference_id=source_reference_id),
                SuperVisualLayerSpec(name="headline", layer_type="headline", composition_role="attention_anchor"),
                SuperVisualLayerSpec(name="support line", layer_type="support_text", composition_role="meaning_closure"),
                SuperVisualLayerSpec(name="brand mark", layer_type="brand_mark", composition_role="brand_memory"),
            ],
        )

    def plan_provider_jobs(
        self,
        *,
        layer_plan: SuperVisualLayerPlan,
        decision: CompositionDecisionReceipt | None,
        frame_profile: FrameProfileCode,
        style_route_code: str,
    ) -> list[ProviderJobSpec]:
        if decision is None:
            raise ValueError("CompositionDecisionReceipt is required before provider job planning")
        jobs: list[ProviderJobSpec] = []
        for layer in layer_plan.layers:
            if not layer.requires_provider_materialization:
                continue
            if layer.source_reference_id is None:
                raise ValueError("provider-materialized layers require source_reference_id")
            payload = {
                "decision": str(decision.composition_decision_receipt_id),
                "layer": str(layer.layer_id),
                "style_route": style_route_code,
                "frame": frame_profile.value,
            }
            jobs.append(
                ProviderJobSpec(
                    provider="fake_image_provider",
                    source_reference_id=layer.source_reference_id,
                    primitive_binding_ref="primitive.fake.primary_binding",
                    style_route_code=style_route_code,
                    frame_profile=frame_profile,
                    composition_role=layer.composition_role,
                    target_layer_id=layer.layer_id,
                    idempotency_key=stable_hash(payload),
                )
            )
        return jobs

    def execute_fake_provider_jobs(self, jobs: list[ProviderJobSpec]) -> tuple[list[ProviderJobReceipt], list[MaterializedAsset]]:
        receipts: list[ProviderJobReceipt] = []
        assets: list[MaterializedAsset] = []
        for job in jobs:
            asset_payload = {
                "provider_job_spec_id": str(job.provider_job_spec_id),
                "source_reference_id": str(job.source_reference_id),
                "style_route": job.style_route_code,
                "frame_profile": job.frame_profile.value,
                "composition_role": job.composition_role,
            }
            asset_hash = stable_hash(asset_payload)
            receipt = ProviderJobReceipt(
                provider_job_spec_id=job.provider_job_spec_id,
                status="completed",
                output_asset_ref=f"fake://supervisual/assets/{asset_hash[:16]}.png",
                output_sha256=asset_hash,
            )
            receipts.append(receipt)
            assets.append(
                MaterializedAsset(
                    source_provider_job_receipt_id=receipt.provider_job_receipt_id,
                    asset_ref=receipt.output_asset_ref,
                    sha256=asset_hash,
                    approved_for_render=True,
                )
            )
        return receipts, assets

    def compile_render_contract(
        self,
        *,
        layer_plan: SuperVisualLayerPlan,
        frame_profile: FrameProfileCode,
        assets: list[MaterializedAsset],
    ) -> SuperVisualRenderContract:
        payload = {
            "layer_plan_id": str(layer_plan.layer_plan_id),
            "frame_profile": frame_profile.value,
            "asset_hashes": [asset.sha256 for asset in assets],
            "renderer": "fake_skia",
            "seed": "cmf-supervisual-v1",
        }
        return SuperVisualRenderContract(
            frame_profile=frame_profile,
            layer_plan_id=layer_plan.layer_plan_id,
            materialized_asset_hashes=[asset.sha256 for asset in assets],
            renderer="fake_skia",
            deterministic=True,
            render_seed="cmf-supervisual-v1",
            contract_hash=stable_hash(payload),
        )

    def run_eval(self, render_contract: SuperVisualRenderContract) -> SuperVisualEvaluationReceipt:
        return SuperVisualEvaluationReceipt(
            render_contract_id=render_contract.render_contract_id,
            source_fidelity_score=0.91,
            primitive_fit_score=0.9,
            composition_fidelity_score=0.93,
            mobile_readability_score=0.88,
            doctrine_boundary_passed=True,
            decision="pass",
            blockers=[],
        )

    def build_with_fake_providers(self, request: CreateSuperVisualRequest) -> SuperVisualBuildResult:
        context = self.hydrate_context(request)
        brief = self.compile_brief(request, context)
        reference_board = self.prepare_reference_board(brief, context)
        copy_packet = self.compile_copy_packet(request)
        hypotheses = self.generate_composition_hypotheses(request)
        selected = hypotheses[0]
        decision = self.lock_composition(selected, request.operator_id)
        layer_plan = self.compile_layer_plan(decision, request.source_reference_ids[0])
        provider_jobs = self.plan_provider_jobs(
            layer_plan=layer_plan,
            decision=decision,
            frame_profile=selected.frame_profile,
            style_route_code=selected.style_route_code,
        )
        provider_receipts, assets = self.execute_fake_provider_jobs(provider_jobs)
        render_contract = self.compile_render_contract(layer_plan=layer_plan, frame_profile=selected.frame_profile, assets=assets)
        eval_receipt = self.run_eval(render_contract)
        variant = SuperVisualVariant(
            state=SuperVisualState.evaluated,
            brief=brief,
            reference_board=reference_board,
            copy_packet=copy_packet,
            composition_hypotheses=hypotheses,
            composition_decision=decision,
            layer_plan=layer_plan,
            provider_jobs=provider_jobs,
            provider_receipts=provider_receipts,
            materialized_assets=assets,
            render_contract=render_contract,
            evaluation_receipt=eval_receipt,
        )
        project = SuperVisualProject(
            brand_id=request.brand_id,
            brand_context_version_id=request.brand_context_version_id,
            context_packet=context,
            state=SuperVisualState.evaluated,
            variants=[variant],
        )
        return SuperVisualBuildResult(
            project=project,
            receipts=[
                str(decision.composition_decision_receipt_id),
                *[str(receipt.provider_job_receipt_id) for receipt in provider_receipts],
                str(eval_receipt.evaluation_receipt_id),
            ],
            fake_provider_mode=True,
        )
