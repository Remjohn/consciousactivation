"""Runtime contracts for the SuperVisual Builder component.

These contracts sit above the existing still-visual runtime. They do not replace
still_visuals.py; they define the higher-level SuperVisual production path that
uses shared skill packs, fake/real providers, deterministic render contracts,
and evaluation receipts.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, model_validator

from ccp_studio.contracts.frame_profiles import FrameProfileCode


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def stable_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()


class SuperVisualState(str, Enum):
    created = "created"
    context_hydrated = "context_hydrated"
    planned = "planned"
    composition_locked = "composition_locked"
    provider_planned = "provider_planned"
    materialized = "materialized"
    rendered = "rendered"
    evaluated = "evaluated"
    revision_required = "revision_required"
    approved = "approved"
    exported = "exported"


class SuperVisualOutputKind(str, Enum):
    feed_poster = "feed_poster"
    square_editorial = "square_editorial"
    proof_card = "proof_card"
    vertical_visual = "vertical_visual"


class SuperVisualContextPacket(BaseModel):
    schema_version: Literal["cmf.supervisual_context_packet.v1"] = "cmf.supervisual_context_packet.v1"
    context_packet_id: UUID = Field(default_factory=uuid4)
    brand_id: UUID
    brand_context_version_id: UUID
    operator_id: UUID
    source_reference_ids: list[UUID] = Field(min_length=1)
    source_expression_refs: list[str] = Field(default_factory=list)
    content_archetype: str = Field(min_length=1)
    target_output_kind: SuperVisualOutputKind
    requested_frame_profile: FrameProfileCode
    created_at: datetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def delivery_frame_must_not_be_16_9(self):
        if self.requested_frame_profile.value.startswith("16:9"):
            raise ValueError("16:9 is source-only and cannot be a SuperVisual delivery frame profile")
        return self


class SuperVisualBrief(BaseModel):
    schema_version: Literal["cmf.supervisual_brief.v1"] = "cmf.supervisual_brief.v1"
    brief_id: UUID = Field(default_factory=uuid4)
    context_packet_id: UUID
    primitive_coalition_contract_ref: str = Field(min_length=1)
    visual_schema_ref: str = Field(min_length=1)
    one_sentence_job: str = Field(min_length=1)
    source_truth: str = Field(min_length=1)
    audience_question: str = Field(min_length=1)
    expected_viewer_state: str = Field(min_length=1)
    forbidden_generic_patterns: list[str] = Field(default_factory=list)


class SuperVisualReferenceBoard(BaseModel):
    schema_version: Literal["cmf.supervisual_reference_board.v1"] = "cmf.supervisual_reference_board.v1"
    reference_board_id: UUID = Field(default_factory=uuid4)
    brief_id: UUID
    required_ingredient_refs: list[str] = Field(default_factory=list)
    selected_source_reference_ids: list[UUID] = Field(min_length=1)
    missing_required_ingredients: list[str] = Field(default_factory=list)
    coverage_score: float = Field(ge=0, le=1)


class SuperVisualCopyPacket(BaseModel):
    schema_version: Literal["cmf.supervisual_copy_packet.v1"] = "cmf.supervisual_copy_packet.v1"
    copy_packet_id: UUID = Field(default_factory=uuid4)
    headline: str = Field(min_length=1, max_length=120)
    support_line: str = Field(min_length=1, max_length=180)
    microcopy: list[str] = Field(default_factory=list)
    caption_seed: str = Field(default="")
    source_fidelity_note: str = Field(min_length=1)


class SuperVisualCompositionHypothesis(BaseModel):
    schema_version: Literal["cmf.supervisual_composition_hypothesis.v1"] = "cmf.supervisual_composition_hypothesis.v1"
    hypothesis_id: UUID = Field(default_factory=uuid4)
    composition_template_code: str = Field(min_length=1)
    frame_profile: FrameProfileCode
    style_route_code: str = Field(min_length=1)
    attention_path: list[str] = Field(min_length=1)
    primitive_fit_score: float = Field(ge=0, le=1)
    risks: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def hypothesis_delivery_frame_must_not_be_16_9(self):
        if self.frame_profile.value.startswith("16:9"):
            raise ValueError("16:9 cannot be selected as a SuperVisual delivery hypothesis")
        return self


class CompositionDecisionReceipt(BaseModel):
    schema_version: Literal["cmf.supervisual_composition_decision_receipt.v1"] = "cmf.supervisual_composition_decision_receipt.v1"
    composition_decision_receipt_id: UUID = Field(default_factory=uuid4)
    selected_hypothesis_id: UUID
    locked_by: UUID
    locked_at: datetime = Field(default_factory=utc_now)
    decision_reason: str = Field(min_length=1)
    accepted_risks: list[str] = Field(default_factory=list)


class SuperVisualLayerSpec(BaseModel):
    schema_version: Literal["cmf.supervisual_layer_spec.v1"] = "cmf.supervisual_layer_spec.v1"
    layer_id: UUID = Field(default_factory=uuid4)
    name: str = Field(min_length=1)
    layer_type: Literal["background", "card", "headline", "support_text", "hero_asset", "proof_object", "annotation", "brand_mark", "shadow"]
    composition_role: str = Field(min_length=1)
    deterministic: bool = True
    requires_provider_materialization: bool = False
    source_reference_id: UUID | None = None


class SuperVisualLayerPlan(BaseModel):
    schema_version: Literal["cmf.supervisual_layer_plan.v1"] = "cmf.supervisual_layer_plan.v1"
    layer_plan_id: UUID = Field(default_factory=uuid4)
    composition_decision_receipt_id: UUID
    layers: list[SuperVisualLayerSpec] = Field(min_length=1)


class ProviderJobSpec(BaseModel):
    schema_version: Literal["cmf.supervisual_provider_job_spec.v1"] = "cmf.supervisual_provider_job_spec.v1"
    provider_job_spec_id: UUID = Field(default_factory=uuid4)
    provider: Literal["fake_image_provider", "fake_cutout_provider", "fake_layer_provider", "ideogram", "gpt_image", "flux", "qwen_image_layered", "sam3"]
    source_reference_id: UUID
    primitive_binding_ref: str = Field(min_length=1)
    style_route_code: str = Field(min_length=1)
    frame_profile: FrameProfileCode
    composition_role: str = Field(min_length=1)
    target_layer_id: UUID
    idempotency_key: str = Field(min_length=1)

    @model_validator(mode="after")
    def provider_frame_must_not_be_16_9_delivery(self):
        if self.frame_profile.value.startswith("16:9"):
            raise ValueError("provider jobs cannot target 16:9 delivery for SuperVisual")
        return self


class ProviderJobReceipt(BaseModel):
    schema_version: Literal["cmf.supervisual_provider_job_receipt.v1"] = "cmf.supervisual_provider_job_receipt.v1"
    provider_job_receipt_id: UUID = Field(default_factory=uuid4)
    provider_job_spec_id: UUID
    status: Literal["planned", "queued", "completed", "failed"]
    output_asset_ref: str
    output_sha256: str = Field(min_length=64, max_length=64)
    created_at: datetime = Field(default_factory=utc_now)


class MaterializedAsset(BaseModel):
    schema_version: Literal["cmf.supervisual_materialized_asset.v1"] = "cmf.supervisual_materialized_asset.v1"
    materialized_asset_id: UUID = Field(default_factory=uuid4)
    source_provider_job_receipt_id: UUID
    asset_ref: str = Field(min_length=1)
    sha256: str = Field(min_length=64, max_length=64)
    approved_for_render: bool = False


class SuperVisualRenderContract(BaseModel):
    schema_version: Literal["cmf.supervisual_render_contract.v1"] = "cmf.supervisual_render_contract.v1"
    render_contract_id: UUID = Field(default_factory=uuid4)
    frame_profile: FrameProfileCode
    layer_plan_id: UUID
    materialized_asset_hashes: list[str] = Field(default_factory=list)
    renderer: Literal["fake_skia", "skia"] = "fake_skia"
    deterministic: bool = True
    render_seed: str = Field(default="cmf-supervisual-v1")
    contract_hash: str = Field(min_length=64, max_length=64)

    @model_validator(mode="after")
    def render_is_deterministic_delivery(self):
        if not self.deterministic:
            raise ValueError("SuperVisual final render contract must be deterministic")
        if self.frame_profile.value.startswith("16:9"):
            raise ValueError("SuperVisual render contract cannot target 16:9 delivery")
        return self


class SuperVisualEvaluationReceipt(BaseModel):
    schema_version: Literal["cmf.supervisual_evaluation_receipt.v1"] = "cmf.supervisual_evaluation_receipt.v1"
    evaluation_receipt_id: UUID = Field(default_factory=uuid4)
    render_contract_id: UUID
    source_fidelity_score: float = Field(ge=0, le=1)
    primitive_fit_score: float = Field(ge=0, le=1)
    composition_fidelity_score: float = Field(ge=0, le=1)
    mobile_readability_score: float = Field(ge=0, le=1)
    doctrine_boundary_passed: bool
    decision: Literal["pass", "repair_required", "blocked"]
    blockers: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def decision_matches_hard_gates(self):
        if self.decision == "pass":
            if self.source_fidelity_score < 0.8 or not self.doctrine_boundary_passed:
                raise ValueError("passing SuperVisual eval requires source fidelity >= .8 and doctrine boundary pass")
        return self


class SuperVisualVariant(BaseModel):
    schema_version: Literal["cmf.supervisual_variant.v1"] = "cmf.supervisual_variant.v1"
    variant_id: UUID = Field(default_factory=uuid4)
    state: SuperVisualState
    brief: SuperVisualBrief
    reference_board: SuperVisualReferenceBoard | None = None
    copy_packet: SuperVisualCopyPacket | None = None
    composition_hypotheses: list[SuperVisualCompositionHypothesis] = Field(default_factory=list)
    composition_decision: CompositionDecisionReceipt | None = None
    layer_plan: SuperVisualLayerPlan | None = None
    provider_jobs: list[ProviderJobSpec] = Field(default_factory=list)
    provider_receipts: list[ProviderJobReceipt] = Field(default_factory=list)
    materialized_assets: list[MaterializedAsset] = Field(default_factory=list)
    render_contract: SuperVisualRenderContract | None = None
    evaluation_receipt: SuperVisualEvaluationReceipt | None = None


class SuperVisualProject(BaseModel):
    schema_version: Literal["cmf.supervisual_project.v1"] = "cmf.supervisual_project.v1"
    project_id: UUID = Field(default_factory=uuid4)
    brand_id: UUID
    brand_context_version_id: UUID
    context_packet: SuperVisualContextPacket
    state: SuperVisualState
    variants: list[SuperVisualVariant] = Field(min_length=1)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class CreateSuperVisualRequest(BaseModel):
    schema_version: Literal["cmf.create_supervisual_request.v1"] = "cmf.create_supervisual_request.v1"
    brand_id: UUID
    brand_context_version_id: UUID
    operator_id: UUID
    source_reference_ids: list[UUID] = Field(min_length=1)
    source_expression_refs: list[str] = Field(default_factory=list)
    content_archetype: str = "conceptual_supervisual"
    target_output_kind: SuperVisualOutputKind = SuperVisualOutputKind.feed_poster
    requested_frame_profile: FrameProfileCode = FrameProfileCode.feed_poster
    preferred_style_route_code: str = "style.gmg.expert_04.paper_architect.v1"
    source_truth: str = "Source-grounded transformation insight."
    audience_question: str = "Why does this matter to me now?"
    expected_viewer_state: str = "recognition_then_clarity"

    @model_validator(mode="after")
    def request_delivery_frame_must_not_be_16_9(self):
        if self.requested_frame_profile.value.startswith("16:9"):
            raise ValueError("16:9 is source-only and cannot be requested as a SuperVisual delivery frame profile")
        return self


class SuperVisualBuildResult(BaseModel):
    schema_version: Literal["cmf.supervisual_build_result.v1"] = "cmf.supervisual_build_result.v1"
    project: SuperVisualProject
    receipts: list[str]
    fake_provider_mode: bool = True
