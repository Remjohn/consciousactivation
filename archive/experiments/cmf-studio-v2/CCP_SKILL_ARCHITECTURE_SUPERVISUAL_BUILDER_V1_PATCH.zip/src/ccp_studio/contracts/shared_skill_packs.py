"""Contracts for shared and engine-specific skill manifests."""

from __future__ import annotations

from enum import Enum
from typing import Literal
from pydantic import BaseModel, Field


class SkillScope(str, Enum):
    shared = "shared"
    engine_specific = "engine_specific"


class RuntimeAccuracyPolicy(BaseModel):
    pydantic_validation: Literal["required"] = "required"
    dspy_reasoning: str = "allowed_when_dspy_program_is_not_null"
    deterministic_guards: Literal["required"] = "required"
    audit_receipt: Literal["required"] = "required"


class SkillPackManifest(BaseModel):
    schema_version: Literal["cmf.skill_pack_manifest.v1"] = "cmf.skill_pack_manifest.v1"
    skill_id: str = Field(min_length=1)
    scope: SkillScope
    owner_agent: str = Field(min_length=1)
    skill_type: str = Field(min_length=1)
    dspy_program: str | None = None
    inputs: list[str] = Field(default_factory=list)
    outputs: list[str] = Field(default_factory=list)
    required_contracts: list[str] = Field(default_factory=list)
    required_registries: list[str] = Field(default_factory=list)
    hard_gates: list[str] = Field(default_factory=list)
    runtime_accuracy: RuntimeAccuracyPolicy = Field(default_factory=RuntimeAccuracyPolicy)
