# Apply Instructions

This patch is additive: it introduces canonical ontology/convergence contracts, services, registries, and tests without modifying existing source files.

## Apply

Copy the contents of `THE CMF STUDIO/` into the root of your existing `THE CMF STUDIO` project.

## Verify

```bash
cd "THE CMF STUDIO"
PYTHONPATH=src python -m compileall -q src
PYTHONPATH=src python -m pytest -q tests/cmf_studio
```

Expected result:

```text
484 passed
```

## Next integration step

After applying, start moving old component-specific contracts toward these canonical contracts through adapters, not direct deletion. The next recommended target is to update still visual / SuperVisual program contracts to reference:

- `PrimitiveCoalitionContract`
- `FrameProfile`
- `StyleRoute`
- `CreativeIngredient`
- `VisualIngredientProgram`
- `RegistryConsolidationService`
