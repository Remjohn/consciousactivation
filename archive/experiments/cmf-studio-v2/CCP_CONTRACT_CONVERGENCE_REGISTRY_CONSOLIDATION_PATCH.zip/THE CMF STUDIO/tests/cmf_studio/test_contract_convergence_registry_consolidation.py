from pathlib import Path
from uuid import uuid4

import pytest

from ccp_studio.contracts.creative_ingredients import (
    CompositionRole,
    CreativeIngredient,
    CreativeIngredientClass,
    SourceReference,
    SourceReferenceKind,
    VisualIngredientProgram,
    visual_ingredient_program_hash,
)
from ccp_studio.contracts.frame_profiles import DEFAULT_FRAME_PROFILES, FrameDeliveryMode, FrameProfile, FrameProfileCode
from ccp_studio.contracts.ontology import MigrationAction
from ccp_studio.contracts.primitive_coalition import PrimitiveCoalitionContract
from ccp_studio.contracts.style_routes import DEFAULT_STYLE_ROUTES, SourceReferenceMode, StyleRoute
from ccp_studio.contracts.visual_preproduction import (
    ConstraintGateCResult,
    KineticVerb,
    PrimalAnalysis,
    StoryboardCommanderVerdict,
    StoryboardIngredient,
    TCode,
    VAEDecoder,
    VCode,
    VisualAnalystReport,
    VisualSchema,
)
from ccp_studio.services.contract_convergence_service import ContractConvergenceService
from ccp_studio.services.registry_consolidation_service import RegistryConsolidationService


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_frame_profiles_make_16_9_source_only_and_square_soft_card_first_class():
    profiles = {profile.code: profile for profile in DEFAULT_FRAME_PROFILES}
    assert profiles[FrameProfileCode.source_interview_16_9].delivery_mode == FrameDeliveryMode.source_only
    assert profiles[FrameProfileCode.square_soft_rounded_editorial].inner_frame.corner_radius > 0
    with pytest.raises(ValueError):
        FrameProfile(
            code=FrameProfileCode.source_interview_16_9,
            display_name="Bad 16:9 Delivery",
            delivery_mode=FrameDeliveryMode.delivery,
            width=1920,
            height=1080,
            caption_policy={"placement": "none", "max_lines": 0},
        )


def test_style_routes_preserve_motion_and_visual_skill_requirements():
    routes = {route.route_code: route for route in DEFAULT_STYLE_ROUTES}
    assert routes["style.cac.conscious_ambient_cinema.v1"].requires_real_reference is True
    assert "real_life_reference" in routes["style.cac.conscious_ambient_cinema.v1"].required_inputs
    assert routes["style.gmg.expert_03.emotional_animator.v1"].expert.value.startswith("gmg-expert-03")
    assert "photo_cutout_object" in routes["style.gmg.expert_03.emotional_animator.v1"].required_inputs
    assert routes["style.gmg.expert_06.visual_synthesizer.v1"].requires_real_reference is False


def test_contract_convergence_projects_legacy_primitive_triad_into_canonical_coalition():
    service = ContractConvergenceService()
    coalition = service.primitive_triad_projection(
        meaning_transform="PRM-STR-bird-by-bird",
        delivery_shape="PRM-VSG-concrete-object",
        format_material="EXP-FBK-payoff",
        coalition_intent="Preserve a legacy SuperVisual primitive triad while moving to PrimitiveCoalitionContract.",
        source_context_refs={"legacy_contract": "PrimitiveTriadContract"},
    )
    assert isinstance(coalition, PrimitiveCoalitionContract)
    assert coalition.coalition_signature.startswith("legacy:")
    assert len(coalition.primary_bindings) == 3
    receipt = service.new_receipt(
        source_contract_refs=["contracts/asset_program_compilers.py::PrimitiveTriadContract"],
        canonical_contract_ref="contracts/primitive_coalition.py::PrimitiveCoalitionContract",
        decision=MigrationAction.wrap,
        test_refs=["test_contract_convergence_registry_consolidation.py"],
    )
    assert receipt.adapter_required is True


def test_visual_schema_and_storyboard_gate_enforce_preproduction_specificity():
    visual_schema = VisualSchema(
        project_id="proj_001",
        brand_context_version_ref="bcv_001",
        source_transcript_ref="transcript_001",
        brand_avatar_physical_dna="Specific coach avatar physical DNA copied verbatim.",
        contextual_clues=["chipped ceramic mug", "late-night kitchen table"],
        human_scale_spaces=["small kitchen"],
        cultural_symbols=["WhatsApp voice note bubble"],
    )
    primal = PrimalAnalysis(
        feeling="A quiet collapse disguised as composure.",
        body_truth="Hands grip the chipped mug while shoulders stay unnaturally upright.",
        environment="Small kitchen table at night.",
        timestamp_quote="I did not know where to look anymore.",
        timestamp="00:14:23",
        uniqueness="The chipped mug and posture come from this person's transcript.",
    )
    vae = VAEDecoder(
        semantic_check="contained panic rather than visible breakdown",
        shadow_filter="show pressure through gripping, not crying",
        stock_cliche="woman crying alone in dark room",
        real_approach="upright person gripping a chipped mug under kitchen light",
    )
    gate = ConstraintGateCResult(
        character_anchor_vs_action_pass=True,
        lighting_anti_cliche_pass=True,
        environment_source_hierarchy_pass=True,
        word_count_physics_pass=True,
        shot_distribution_pass=True,
        cascade_lock_pass=True,
    )
    ingredient = StoryboardIngredient(
        beat_id="beat_001",
        visual_schema_id=visual_schema.visual_schema_id,
        visual_cinematic_premise="A tactile closeup of restraint under pressure.",
        t_code=TCode.T1,
        v_code=VCode.V5,
        kinetic_verb=KineticVerb.gripping,
        lighting_preset=6,
        shot_type="Tactile Close-Up",
        primal=primal,
        vae=vae,
        constraint_gate_c=gate,
    )
    report = VisualAnalystReport(
        storyboard_ingredient_id=ingredient.storyboard_ingredient_id,
        checks={"character_anchor": "pass", "timestamp": "pass", "kinetic_verb": "pass"},
        decision="approved_for_prompt",
    )
    assert report.decision == "approved_for_prompt"
    with pytest.raises(ValueError):
        StoryboardCommanderVerdict(
            project_id="proj_001",
            storyboard_batch_ref="batch_001",
            visual_anchor_block_present=False,
            atomic_task_list_present=True,
            tone_consistent=True,
            palette_consistent=True,
            avatar_consistent=True,
            decision="authorized",
        )


def test_visual_ingredient_program_blocks_real_reference_missing_for_real_route():
    brand_id = uuid4()
    source = SourceReference(
        kind=SourceReferenceKind.client_upload,
        source_ref="s3://brand/uploads/calendar.png",
        rights_status="client_owned",
        description="Client-owned calendar screenshot.",
    )
    ingredient = CreativeIngredient(
        brand_id=brand_id,
        brand_context_version_ref="bcv_001",
        source_references=[source],
        ingredient_class=CreativeIngredientClass.proof_object,
        ingredient_role="background_proof_texture",
        allowed_frame_profiles=[FrameProfileCode.square_soft_rounded_editorial],
        composition_roles=[CompositionRole.proof_insert],
        style_route_codes_allowed=["style.gmg.expert_04.paper_architect.v1"],
        preferred_style_route_code="style.gmg.expert_04.paper_architect.v1",
    )
    route = next(r for r in DEFAULT_STYLE_ROUTES if r.route_code == "style.gmg.expert_04.paper_architect.v1")
    payload = {
        "creative_ingredient_id": ingredient.creative_ingredient_id,
        "source_reference_mode": SourceReferenceMode.direct_real_reference,
        "style_route": route,
        "frame_profile": FrameProfileCode.square_soft_rounded_editorial,
        "composition_role": CompositionRole.proof_insert,
        "prompt_sections": {"anchor": "calendar screenshot", "composition": "paper proof card"},
        "evaluation_requirements": {"recognizability": 0.8},
    }
    payload["program_hash"] = visual_ingredient_program_hash(payload)
    program = VisualIngredientProgram.model_validate(payload)
    assert program.frame_profile == FrameProfileCode.square_soft_rounded_editorial

    bad_payload = {**payload, "source_reference_mode": SourceReferenceMode.abstract_symbolic_exception}
    bad_payload["program_hash"] = visual_ingredient_program_hash(bad_payload)
    with pytest.raises(ValueError):
        VisualIngredientProgram.model_validate(bad_payload)


def test_canonical_registry_manifest_loads_style_routes_and_frame_profiles():
    service = RegistryConsolidationService.from_project_root(PROJECT_ROOT)
    manifest = service.load_manifest()
    assert manifest.canonical_entries
    namespaces = service.namespaces_present()
    assert "registry.visual.style_route" in {namespace.value for namespace in namespaces}
    assert "registry.composition.frame_profile" in {namespace.value for namespace in namespaces}
    crosswalk = service.crosswalk_for_source("registries/primitives/meaning_plane")
    assert crosswalk.canonical_namespace.value == "registry.primitive.meaning"
