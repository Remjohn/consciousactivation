# CCP Studio Ontology Architecture

This folder is the canonical planning surface for Contract Convergence and Registry Consolidation.

## Source-of-truth sequence

1. `CCP_STUDIO_MASTER_ONTOLOGY_V1.md`
2. `ccp_master_glossary_v1.json`
3. `ccp_integration_matrix_v1.csv`
4. `03_CONTRACT_CONVERGENCE_PLAN.md`
5. `04_REGISTRY_CONSOLIDATION_PLAN.md`

## Runtime contracts

The executable Pydantic contracts live in:

- `src/ccp_studio/contracts/ontology.py`
- `src/ccp_studio/contracts/primitive_coalition.py`
- `src/ccp_studio/contracts/frame_profiles.py`
- `src/ccp_studio/contracts/style_routes.py`
- `src/ccp_studio/contracts/creative_ingredients.py`
- `src/ccp_studio/contracts/visual_preproduction.py`
- `src/ccp_studio/contracts/registry_consolidation.py`

## Hard integration rule

No component should introduce a new concept without adding or mapping an `OntologyTerm`.
No registry should remain active without a canonical namespace or crosswalk entry.
