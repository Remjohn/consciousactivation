"""Contract convergence helpers for V1→V2 migration.

The service produces convergence receipts and compatibility projections. It does
not delete old contracts; this enables a strangler-refactor migration while the
test suite remains green.
"""

from __future__ import annotations

from dataclasses import dataclass

from ccp_studio.contracts.ontology import ContractConvergenceReceipt, MigrationAction, convergence_receipt_hash
from ccp_studio.contracts.primitive_coalition import PrimitiveCoalitionContract, simple_triad_to_coalition


class ContractConvergenceServiceError(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class ContractConvergenceService:
    actor_ref: str = "system"

    def new_receipt(
        self,
        *,
        source_contract_refs: list[str],
        canonical_contract_ref: str,
        decision: MigrationAction,
        adapter_required: bool = True,
        compatibility_notes: list[str] | None = None,
        test_refs: list[str] | None = None,
    ) -> ContractConvergenceReceipt:
        receipt_hash = convergence_receipt_hash(
            source_contract_refs=source_contract_refs,
            canonical_contract_ref=canonical_contract_ref,
            decision=decision,
            adapter_required=adapter_required,
            compatibility_notes=compatibility_notes or [],
            test_refs=test_refs or [],
        )
        return ContractConvergenceReceipt(
            source_contract_refs=source_contract_refs,
            canonical_contract_ref=canonical_contract_ref,
            decision=decision,
            adapter_required=adapter_required,
            compatibility_notes=compatibility_notes or [],
            test_refs=test_refs or [],
            receipt_hash=receipt_hash,
        )

    def primitive_triad_projection(
        self,
        *,
        meaning_transform: str,
        delivery_shape: str,
        format_material: str,
        coalition_intent: str,
        source_context_refs: dict[str, str] | None = None,
    ) -> PrimitiveCoalitionContract:
        if not meaning_transform or not delivery_shape or not format_material:
            raise ContractConvergenceServiceError("INVALID_PRIMITIVE_TRIAD", "All primitive triad fields are required.")
        return simple_triad_to_coalition(
            meaning_transform=meaning_transform,
            delivery_shape=delivery_shape,
            format_material=format_material,
            coalition_intent=coalition_intent,
            source_context_refs=source_context_refs,
        )
