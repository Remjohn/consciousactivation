"""Canonical registry consolidation service.

This service is intentionally read-only for the first convergence pass. It loads
the canonical registry manifest created under `registries/canonical` and exposes
query helpers that future component engines can use without reading scattered
legacy registry folders directly.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from ccp_studio.contracts.registry_consolidation import (
    CanonicalRegistryEntry,
    CanonicalRegistryNamespace,
    RegistryConsolidationManifest,
    RegistryCrosswalkEntry,
)


class RegistryConsolidationServiceError(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class RegistryConsolidationService:
    manifest_path: Path

    @classmethod
    def from_project_root(cls, project_root: Path) -> "RegistryConsolidationService":
        return cls(project_root / "registries" / "canonical" / "registry" / "consolidation_manifest.v1.json")

    def load_manifest(self) -> RegistryConsolidationManifest:
        if not self.manifest_path.exists():
            raise RegistryConsolidationServiceError(
                "CANONICAL_REGISTRY_MANIFEST_MISSING",
                f"Canonical registry manifest not found: {self.manifest_path}",
            )
        payload = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        return RegistryConsolidationManifest.model_validate(payload)

    def entries(self, namespace: CanonicalRegistryNamespace | None = None) -> list[CanonicalRegistryEntry]:
        manifest = self.load_manifest()
        if namespace is None:
            return list(manifest.canonical_entries)
        return [entry for entry in manifest.canonical_entries if entry.namespace == namespace]

    def entry_by_id(self, entry_id: str) -> CanonicalRegistryEntry:
        for entry in self.entries():
            if entry.entry_id == entry_id:
                return entry
        raise RegistryConsolidationServiceError("CANONICAL_REGISTRY_ENTRY_NOT_FOUND", entry_id)

    def crosswalk_for_source(self, source_path: str) -> RegistryCrosswalkEntry:
        manifest = self.load_manifest()
        for crosswalk in manifest.crosswalk:
            if crosswalk.source_path == source_path:
                return crosswalk
        raise RegistryConsolidationServiceError("REGISTRY_CROSSWALK_NOT_FOUND", source_path)

    def namespaces_present(self) -> set[CanonicalRegistryNamespace]:
        return {entry.namespace for entry in self.entries()}
