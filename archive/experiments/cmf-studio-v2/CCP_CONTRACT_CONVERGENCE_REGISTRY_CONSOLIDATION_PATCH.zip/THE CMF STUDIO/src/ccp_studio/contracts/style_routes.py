"""Visual style route contracts for CAC, GMG, Paper-Cut, Documentary, and UI routes."""

from __future__ import annotations

from enum import Enum
from typing import Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, model_validator

from ccp_studio.contracts.frame_profiles import FrameProfileCode


class StyleFamily(str, Enum):
    cac = "CAC"
    gmg = "GMG"
    paper_cut = "PAPER_CUT"
    documentary_proof = "DOCUMENTARY_PROOF"
    ui_reaction = "UI_REACTION"
    avatar_performance = "AVATAR_PERFORMANCE"


class StyleExpertCode(str, Enum):
    cac_composer = "cac-composer"
    cac_analyst = "cac-analyst"
    gmg_composer = "gmg-composer"
    gmg_analyst = "gmg-analyst"
    gmg_expert_01 = "gmg-expert-01-neo-schematic-architect"
    gmg_expert_02 = "gmg-expert-02-mono-kinetic-protagonist"
    gmg_expert_03 = "gmg-expert-03-emotional-animator"
    gmg_expert_04 = "gmg-expert-04-paper-architect"
    gmg_expert_05 = "gmg-expert-05-editorial-scribe"
    gmg_expert_06 = "gmg-expert-06-visual-synthesizer"
    paper_cut_artifact = "paper-cut-artifact"
    documentary_proof = "documentary-proof"
    ui_reaction_surface = "ui-reaction-surface"
    avatar_performance_layer = "avatar-performance-layer"


class SourceReferenceMode(str, Enum):
    direct_real_reference = "direct_real_reference"
    composite_real_references = "composite_real_references"
    style_reference_only = "style_reference_only"
    abstract_symbolic_exception = "abstract_symbolic_exception"
    source_language_reference = "source_language_reference"


class StyleRoute(BaseModel):
    schema_version: Literal["cmf.style_route.v1"] = "cmf.style_route.v1"
    style_route_id: UUID = Field(default_factory=uuid4)
    route_code: str = Field(min_length=1)
    family: StyleFamily
    expert: StyleExpertCode | None = None
    display_name: str = Field(min_length=1)
    purpose: str = Field(min_length=1)
    requires_real_reference: bool = True
    allowed_reference_modes: list[SourceReferenceMode] = Field(min_length=1)
    required_inputs: list[str] = Field(default_factory=list)
    compatible_frame_profiles: list[FrameProfileCode] = Field(default_factory=list)
    compatible_content_formats: list[str] = Field(default_factory=list)
    primitive_affinities: list[str] = Field(default_factory=list)
    forbidden_patterns: list[str] = Field(default_factory=list)
    validation_agent: str | None = None

    @model_validator(mode="after")
    def real_reference_route_needs_real_mode(self):
        if self.requires_real_reference and not any(
            mode in self.allowed_reference_modes
            for mode in (SourceReferenceMode.direct_real_reference, SourceReferenceMode.composite_real_references)
        ):
            raise ValueError("routes requiring real references must allow direct or composite real reference modes")
        return self


DEFAULT_STYLE_ROUTES: list[StyleRoute] = [
    StyleRoute(
        route_code="style.cac.conscious_ambient_cinema.v1",
        family=StyleFamily.cac,
        expert=StyleExpertCode.cac_composer,
        display_name="CAC — Conscious Ambient Cinema",
        purpose="Editorial cinematic realism and B-roll grounded in real-life reference.",
        requires_real_reference=True,
        allowed_reference_modes=[SourceReferenceMode.direct_real_reference, SourceReferenceMode.composite_real_references],
        required_inputs=["visual_schema", "brand_avatar", "transcript_beat", "real_life_reference"],
        compatible_frame_profiles=[FrameProfileCode.vertical_full, FrameProfileCode.square_soft_rounded_editorial, FrameProfileCode.square_cinematic_card],
        primitive_affinities=["narrative_structure", "voice_intimacy", "trust_transfer"],
        forbidden_patterns=["generic_cinematic_sad_person", "unmotivated_light", "cgi_spectacle"],
        validation_agent="visual-analyst",
    ),
    StyleRoute(
        route_code="style.gmg.expert_03.emotional_animator.v1",
        family=StyleFamily.gmg,
        expert=StyleExpertCode.gmg_expert_03,
        display_name="GMG Expert 03 — Emotional Animator",
        purpose="Stick figure plus photorealistic object cutout for maximum relatable emotional illustration.",
        requires_real_reference=True,
        allowed_reference_modes=[SourceReferenceMode.direct_real_reference, SourceReferenceMode.composite_real_references],
        required_inputs=["beat_cluster", "visual_schema", "photo_cutout_object"],
        compatible_frame_profiles=[FrameProfileCode.vertical_full, FrameProfileCode.square_soft_rounded_editorial, FrameProfileCode.feed_poster, FrameProfileCode.carousel_slide],
        primitive_affinities=["recognition", "safe_recovery", "visual_sonic_guidance"],
        forbidden_patterns=["passive_floating_object", "no_photo_cutout"],
        validation_agent="visual-analyst",
    ),
    StyleRoute(
        route_code="style.gmg.expert_04.paper_architect.v1",
        family=StyleFamily.gmg,
        expert=StyleExpertCode.gmg_expert_04,
        display_name="GMG Expert 04 — Paper Architect",
        purpose="Documents, evidence, archives, ripped edges, tape, and tactile proof objects.",
        requires_real_reference=True,
        allowed_reference_modes=[SourceReferenceMode.direct_real_reference, SourceReferenceMode.composite_real_references, SourceReferenceMode.style_reference_only],
        required_inputs=["visual_schema", "proof_or_memory_artifact"],
        compatible_frame_profiles=[FrameProfileCode.vertical_full, FrameProfileCode.square_proof_card, FrameProfileCode.square_soft_rounded_editorial, FrameProfileCode.carousel_slide],
        primitive_affinities=["trust_transfer", "documentary_proof", "memory"],
        forbidden_patterns=["perfect_digital_edge", "unproven_fake_document"],
        validation_agent="visual-analyst",
    ),
    StyleRoute(
        route_code="style.gmg.expert_06.visual_synthesizer.v1",
        family=StyleFamily.gmg,
        expert=StyleExpertCode.gmg_expert_06,
        display_name="GMG Expert 06 — Visual Synthesizer",
        purpose="Pure black/white geometric truth for logic, mechanism, and abstract synthesis.",
        requires_real_reference=False,
        allowed_reference_modes=[SourceReferenceMode.source_language_reference, SourceReferenceMode.abstract_symbolic_exception],
        required_inputs=["primitive_coalition", "source_language_or_concept"],
        compatible_frame_profiles=[FrameProfileCode.vertical_full, FrameProfileCode.square_soft_rounded_editorial, FrameProfileCode.feed_poster, FrameProfileCode.carousel_slide],
        primitive_affinities=["structure", "visual_sonic_guidance", "friction_reduction"],
        forbidden_patterns=["gold_accent", "decorative_geometry"],
        validation_agent="visual-analyst",
    ),
    StyleRoute(
        route_code="style.paper_cut.artifact.v1",
        family=StyleFamily.paper_cut,
        expert=StyleExpertCode.paper_cut_artifact,
        display_name="Paper-Cut Artifact",
        purpose="Transform recognizable real-life objects into tactile paper-cut scene ingredients.",
        requires_real_reference=True,
        allowed_reference_modes=[SourceReferenceMode.direct_real_reference, SourceReferenceMode.composite_real_references],
        required_inputs=["source_artifact", "composition_role", "paper_material_profile"],
        compatible_frame_profiles=[FrameProfileCode.vertical_full, FrameProfileCode.vertical_papercut_explainer, FrameProfileCode.square_soft_rounded_editorial, FrameProfileCode.feed_poster, FrameProfileCode.carousel_slide],
        primitive_affinities=["recognition", "micro_semiotic_anchoring", "visual_sonic_guidance"],
        forbidden_patterns=["lost_object_recognizability", "generic_scrapbook_clutter"],
        validation_agent="visual-analyst",
    ),
]
