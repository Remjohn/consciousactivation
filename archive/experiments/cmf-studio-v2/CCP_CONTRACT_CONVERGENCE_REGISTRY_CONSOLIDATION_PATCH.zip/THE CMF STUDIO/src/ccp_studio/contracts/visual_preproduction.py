"""Visual pre-production contracts from the visual skill stack.

These objects represent the Visual Researcher → Visual Schema → Storyboard
Composer → Visual Analyst → Storyboard Commander pipeline.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, model_validator


class TCode(str, Enum):
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T5 = "T5"
    T6 = "T6"
    T7 = "T7"
    T8 = "T8"


class VCode(str, Enum):
    V1 = "V1"
    V2 = "V2"
    V3 = "V3"
    V4 = "V4"
    V5 = "V5"
    V6 = "V6"
    V7 = "V7"
    V8 = "V8"
    V9 = "V9"
    V10 = "V10"
    V11 = "V11"


class KineticVerb(str, Enum):
    pressing = "PRESSING"
    gripping = "GRIPPING"
    clutching = "CLUTCHING"
    tracing = "TRACING"
    releasing = "RELEASING"
    reaching = "REACHING"
    holding = "HOLDING"
    clenching = "CLENCHING"
    bracing = "BRACING"
    rooting = "ROOTING"


class VisualSchema(BaseModel):
    schema_version: Literal["cmf.visual_schema.v1"] = "cmf.visual_schema.v1"
    visual_schema_id: UUID = Field(default_factory=uuid4)
    project_id: str = Field(min_length=1)
    brand_context_version_ref: str = Field(min_length=1)
    source_transcript_ref: str = Field(min_length=1)
    universal_experiences: list[str] = Field(default_factory=list)
    recognizable_emotions: dict[str, str | list[str]] = Field(default_factory=dict)
    brand_avatar_physical_dna: str = Field(min_length=1)
    decisive_moments: list[str] = Field(default_factory=list)
    contextual_clues: list[str] = Field(default_factory=list)
    human_scale_spaces: list[str] = Field(default_factory=list)
    liminal_spaces: list[str] = Field(default_factory=list)
    cultural_symbols: list[str] = Field(default_factory=list)
    archetypal_compositions: list[str] = Field(default_factory=list)
    natural_framing: list[str] = Field(default_factory=list)
    focal_point_rule: str = "One person. One action. One emotion."
    lighting_contexts: dict[str, str] = Field(default_factory=dict)
    color_palette: dict[str, str] = Field(default_factory=dict)
    nostalgic_aesthetic: str | None = None
    light_quality: dict[str, str] = Field(default_factory=dict)
    visual_tropes_to_use: list[str] = Field(default_factory=list)
    visual_tropes_to_avoid: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def schema_requires_recognition_context(self):
        if not (self.contextual_clues or self.cultural_symbols or self.human_scale_spaces):
            raise ValueError("VisualSchema must contain at least one contextual clue, cultural symbol, or human-scale space")
        return self


class PrimalAnalysis(BaseModel):
    schema_version: Literal["cmf.primal_analysis.v1"] = "cmf.primal_analysis.v1"
    feeling: str = Field(min_length=1)
    body_truth: str = Field(min_length=1)
    environment: str = Field(min_length=1)
    timestamp_quote: str = Field(min_length=1)
    timestamp: str = Field(min_length=1)
    uniqueness: str = Field(min_length=1)


class VAEDecoder(BaseModel):
    schema_version: Literal["cmf.vae_decoder.v1"] = "cmf.vae_decoder.v1"
    semantic_check: str = Field(min_length=1)
    shadow_filter: str = Field(min_length=1)
    stock_cliche: str = Field(min_length=1)
    real_approach: str = Field(min_length=1)


class ConstraintGateCResult(BaseModel):
    schema_version: Literal["cmf.constraint_gate_c_result.v1"] = "cmf.constraint_gate_c_result.v1"
    character_anchor_vs_action_pass: bool
    lighting_anti_cliche_pass: bool
    environment_source_hierarchy_pass: bool
    word_count_physics_pass: bool
    shot_distribution_pass: bool
    cascade_lock_pass: bool
    repair_notes: list[str] = Field(default_factory=list)


class StoryboardIngredient(BaseModel):
    schema_version: Literal["cmf.storyboard_ingredient.v1"] = "cmf.storyboard_ingredient.v1"
    storyboard_ingredient_id: UUID = Field(default_factory=uuid4)
    beat_id: str = Field(min_length=1)
    expression_moment_ref: str | None = None
    visual_schema_id: UUID
    visual_cinematic_premise: str = Field(min_length=1)
    t_code: TCode
    v_code: VCode
    kinetic_verb: KineticVerb
    lighting_preset: int = Field(ge=1, le=12)
    shot_type: str = Field(min_length=1)
    primal: PrimalAnalysis
    vae: VAEDecoder
    constraint_gate_c: ConstraintGateCResult


class VisualAnalystReport(BaseModel):
    schema_version: Literal["cmf.visual_analyst_report.v1"] = "cmf.visual_analyst_report.v1"
    visual_analyst_report_id: UUID = Field(default_factory=uuid4)
    storyboard_ingredient_id: UUID
    checks: dict[str, Literal["pass", "warning", "fail", "critical_fail"]]
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    decision: Literal["approved_for_prompt", "repair_required", "blocked"]

    @model_validator(mode="after")
    def critical_fail_blocks(self):
        if any(value == "critical_fail" for value in self.checks.values()) and self.decision != "blocked":
            raise ValueError("critical visual analyst failures must block")
        return self


class StoryboardCommanderVerdict(BaseModel):
    schema_version: Literal["cmf.storyboard_commander_verdict.v1"] = "cmf.storyboard_commander_verdict.v1"
    storyboard_commander_verdict_id: UUID = Field(default_factory=uuid4)
    project_id: str = Field(min_length=1)
    storyboard_batch_ref: str = Field(min_length=1)
    visual_anchor_block_present: bool
    atomic_task_list_present: bool
    tone_consistent: bool
    palette_consistent: bool
    avatar_consistent: bool
    decision: Literal["authorized", "rejected"]

    @model_validator(mode="after")
    def all_checks_required_for_authorization(self):
        if self.decision == "authorized" and not all(
            [
                self.visual_anchor_block_present,
                self.atomic_task_list_present,
                self.tone_consistent,
                self.palette_consistent,
                self.avatar_consistent,
            ]
        ):
            raise ValueError("storyboard batch cannot be authorized unless all structural checks pass")
        return self
