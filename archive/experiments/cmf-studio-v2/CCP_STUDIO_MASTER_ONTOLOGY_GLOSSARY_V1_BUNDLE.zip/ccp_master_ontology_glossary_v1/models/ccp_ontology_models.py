from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel, Field

TermType = Literal[
    "doctrine","primitive","methodology","contract","registry","component",
    "engine","agent","skill","provider","model","asset","library","composition",
    "format","style","workflow","eval","receipt","ui_surface","storage_object",
    "script_tool","data_object","policy","state_machine"
]

TermStatus = Literal[
    "canonical","canonical_to_create","partial_existing","legacy_alias","deprecated","candidate"
]

MigrationAction = Literal[
    "keep","extend","wrap","merge","split","rename","replace","deprecate","create","map"
]

class OntologyLayer(BaseModel):
    id: int
    key: str
    name: str
    definition: str

class OntologyTerm(BaseModel):
    term_id: str
    canonical_name: str
    aliases: list[str] = Field(default_factory=list)
    type: TermType
    layer: str
    definition: str
    owner_component: str
    source_of_truth: Optional[str] = None
    existing_code_refs: list[str] = Field(default_factory=list)
    existing_doc_refs: list[str] = Field(default_factory=list)
    bundle_refs: list[str] = Field(default_factory=list)
    used_by: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    produces: list[str] = Field(default_factory=list)
    invariants: list[str] = Field(default_factory=list)
    failure_modes: list[str] = Field(default_factory=list)
    status: TermStatus
    migration_action: MigrationAction

class IntegrationMatrixRow(BaseModel):
    concept: str
    existing_code_object: str
    bundle_or_new_object: str
    canonical_name: str
    recommended_action: str
    rationale: str
    priority: str
    target_files: str
