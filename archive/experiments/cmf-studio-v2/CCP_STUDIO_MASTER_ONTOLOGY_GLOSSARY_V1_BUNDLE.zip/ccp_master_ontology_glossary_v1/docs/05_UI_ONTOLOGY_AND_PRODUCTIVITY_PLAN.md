# UI Ontology and Productivity Plan

## Objective

The operator UI should make the system faster by exposing object lineage, active contract, blocked gates, eval evidence, and typed repair commands.

## Global layout

```text
┌──────────────────────────────────────────────┐
│ Top: Brand / Project / Stage / Status         │
├──────────────┬─────────────────┬─────────────┤
│ Left Context │ Center Workbench│ Right Agent │
│ + Lineage    │ + Preview       │ + Inspector │
├──────────────┴─────────────────┴─────────────┤
│ Bottom: Jobs / Versions / Evals / Receipts    │
└──────────────────────────────────────────────┘
```

## Core UI surfaces

1. Ontology Browser
2. Integration Matrix UI
3. Asset Intelligence Studio
4. Visual Preproduction Studio
5. SuperVisual Studio
6. Carousel Builder Workbench
7. Video Timeline Workbench
8. 2D Character Studio
9. Review and Approval Board
10. Publishing Board

## Agent command design

Agent chat should never mutate state directly. It should produce typed commands:

```json
{
  "command": "INCREASE_SOURCE_SPECIFICITY",
  "target_object_type": "VisualIngredientProgram",
  "target_object_id": "...",
  "proposed_actions": [
    "replace_generic_object_with_contextual_clue",
    "rerun_visual_schema_binding",
    "rerun_visual_analyst"
  ],
  "requires_approval": true
}
```

## Productivity principle

The UI must always answer:

```text
What is this object?
Why does it exist?
What governs it?
What is blocked?
What can I do next?
What changed?
What proof do I have?
```
