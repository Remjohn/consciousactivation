# CCP Studio Master Ontology V1

## Purpose

This ontology is the canonical map for CCP Studio. It prevents term drift, duplicate contracts, parallel engines, and provider jobs that bypass primitive, research, composition, or asset constraints.

## Source scan summary

- Python source files: **361**
- Contract files: **82**
- Contract classes discovered: **835**
- Registry files: **344**
- Docs files: **453**
- Tests collected in prior audit: **478 passing**
- Component bundles inventoried: **9**
- Motion skill archive present: **True**
- Visual skill archive present: **True**

## 18 ontology layers

1. **Doctrine Layer** — Non-negotiable creative, ethical, and architectural constraints.
2. **Workspace / Brand Layer** — Brand ownership, identity, consent, voice, visual DNA, and workspace state.
3. **Primitive System Layer** — Meaning and experience primitives, coalitions, edge products, primitive evals.
4. **Methodology / Reasoning Layer** — Reusable reasoning doctrines: CBAR, CCV, RSCS, PRIMAL, VAE, SDA, SFL.
5. **Research Layer** — Guest, audience, visual, asset, source, rights, and performance research.
6. **Interview Intelligence Layer** — Interview briefs, contracts, anchors, expression sessions, and ingredient acquisition.
7. **Content Strategy Layer** — Archetypes, derivatives, packs, content asset codes, reaction/meme mechanisms.
8. **Sequencing Layer** — Viewer-state ordering, open loops, closure contracts, and package sequences.
9. **Creative Ingredient Layer** — Source-reference-bound visual ingredients, style routes, frame profiles, composition roles.
10. **Asset Intelligence Layer** — Scored assets, libraries, provenance, usage, winners, and fatigue.
11. **Visual Style / Motion Skill Layer** — CAC, GMG, paper-cut, documentary, UI reaction, and avatar style routes.
12. **Visual Pre-Production Layer** — Visual Schema, Storyboard Composer, PRIMAL, VAE, T/V-Codes, Visual Analyst.
13. **Composition Layer** — Scene/slide/still/video templates, layer plans, frame profiles, composition receipts.
14. **Component / Engine Layer** — SuperVisual, Carousel, Video, 2D Character, Sequencing, Asset, and Brand engines.
15. **Provider / Tool Layer** — External/local AI models and deterministic/rendering/media tools.
16. **Render / Timeline Layer** — Render contracts, timeline manifests, captions, audio, EDL/OTIO, receipts.
17. **Evaluation / Review Layer** — Eval receipts, review states, approval blockers, repair commands, Telegram review.
18. **Publishing / Memory Layer** — Publishing intents, Publer jobs, performance telemetry, narrative memory, winning libraries.

## Canonical creative pipeline doctrine

```text
Interview Brief
+ Transcript
+ Brand Avatar
+ Strategy Brief
+ Brand Context
        ↓
Primitive Candidate Pass
        ↓
Primitive Coalition Contract
        ↓
Visual Researcher
        ↓
Visual Schema
        ↓
Expression Ingredient Inventory
        ↓
Creative Ingredient Requirements
        ↓
Asset Intelligence Retrieval
        ↓
Storyboard / Composition Planning
        ↓
PRIMAL + VAE + CBAR / Constraint Gates
        ↓
Visual Analyst / Storyboard Commander
        ↓
Style Route
        ↓
Provider Job
        ↓
Composition Program
        ↓
Render
        ↓
Evaluation / Approval / Publishing / Memory
```

## Source-of-truth hierarchy

```text
1. Doctrine
2. Primitive Registry
3. Methodology Docs
4. Core Contracts
5. Registries
6. Services / Workflows
7. Component Engines
8. Provider Adapters
9. UI Workbenches
10. Evals / Receipts
11. Publishing / Memory
```

## Important correction

16:9 is **source/reference only** for short-form. Final short-form outputs should target 9:16, 1:1 soft-rounded editorial, or 4:5 feed/carousel profiles.
