# Glossary Build Report

## Generated artifacts

- `data/ccp_master_glossary_v1.json`
- `data/ccp_master_glossary_v1.csv`
- `data/ccp_ontology_layers_v1.json`
- `data/ccp_integration_matrix_v1.csv`
- `data/ccp_integration_matrix_v1.json`
- `models/ccp_ontology_models.py`
- `data/current_contract_class_inventory_v1.json`
- `data/source_inventory_summary_v1.json`

## Term count

The master glossary contains **593 canonical terms**.

## Term types

```json
{
  "doctrine": 18,
  "contract": 383,
  "primitive": 32,
  "methodology": 25,
  "agent": 4,
  "asset": 24,
  "style": 20,
  "composition": 24,
  "engine": 17,
  "ui_surface": 11,
  "provider": 23,
  "eval": 12
}
```

## Layers

```json
{
  "doctrine": 18,
  "workspace_brand": 20,
  "primitive": 32,
  "methodology": 25,
  "research": 37,
  "interview_intelligence": 25,
  "content_strategy": 20,
  "sequencing": 18,
  "creative_ingredient": 19,
  "asset_intelligence": 24,
  "style_motion": 20,
  "visual_preproduction": 29,
  "composition": 103,
  "component_engine": 71,
  "provider_tool": 23,
  "render_timeline": 40,
  "evaluation_review": 43,
  "publishing_memory": 26
}
```

## Status distribution

```json
{
  "canonical": 18,
  "partial_existing": 517,
  "canonical_to_create": 58
}
```

## Migration-action distribution

```json
{
  "keep": 18,
  "extend": 335,
  "create": 58,
  "map": 182
}
```

## Notes

This is a production ontology, not a prose glossary. Each term includes layer, type, owner, definition, code/doc/bundle refs where available, invariants, failure modes, status, and migration action.
