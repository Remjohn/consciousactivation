# Deduplication and Naming Rules

## Naming rules

1. Use `Program` for an executable production plan.
2. Use `Contract` for constraints and obligations.
3. Use `Receipt` for proof of execution, eval, decision, or lineage.
4. Use `RegistryEntry` for static/versioned definitions.
5. Use `Profile` for brand/person/style/rights/fatigue characteristics.
6. Use `Manifest` for collections of materialized files, layers, or timelines.
7. Use `Plan` for pre-execution choices.
8. Use `Spec` for static request or structured description.
9. Use `Workflow` for long-running stateful process.
10. Use `ReadModel` for UI/query projection.

## Deduplication rules

If two names describe the same production object, keep the name closest to the ontology layer.

Example:
- `SingleImageSceneSpec`, `StillVisualCompositionProgram`, and `SuperVisualVariant` should not all compete as product-level names.
- Use `SuperVisualProgram` as product wrapper.
- Use existing still visual objects as runtime internals.

## Alias rule

Old terms may remain as aliases for compatibility but must reference canonical term IDs.
